// Handles loading a single product via ID query param in product.html
document.addEventListener('DOMContentLoaded', async () => {
    const params = new URLSearchParams(window.location.search);
    const productId = params.get('id');

    if (!productId) {
        document.getElementById('product-details').innerHTML = '<p class="text-error text-center">Product not found.</p>';
        return;
    }

    try {
        const product = await apiFetch(`/products/${productId}`);
        renderProductDetails(product);
    } catch (e) {
        document.getElementById('product-details').innerHTML = '<p class="text-error text-center">Failed to load product details.</p>';
        console.error('Error fetching product:', e);
    }
});

function renderProductDetails(product) {
    const container = document.getElementById('product-details');
    if (!container) return;

    const isOutOfStock = product.stock <= 0;
    const imgSrc = product.imageURL || 'images/product_placeholder.svg';
    const priceDisplay = formatCurrency(product.basePrice);

    let stockDisplay = `<p class="text-success" style="font-weight:600; margin-bottom: 20px;">In Stock (${product.stock} available)</p>`;
    if (isOutOfStock) {
        stockDisplay = `<p class="badge badge-error" style="font-size: 1rem; margin-bottom: 20px;">Out of Stock</p>`;
    }

    container.innerHTML = `
        <div class="card" style="padding: 40px; text-align: center;">
            <img src="${imgSrc}" alt="${product.name}" style="max-height: 400px; margin: 0 auto;">
        </div>
        <div>
            <div style="margin-bottom: 10px;">
                <span class="text-muted" style="text-transform: uppercase; font-size: 0.85rem; letter-spacing: 1px;">
                    ${product.category?.name || 'Category'}
                </span>
            </div>
            <h1 style="margin-bottom: 15px;">${product.name}</h1>
            <h2 class="text-primary" style="font-size: 2rem; margin-bottom: 20px;">${priceDisplay}</h2>
            
            ${stockDisplay}
            
            <p style="color: var(--text-muted); line-height: 1.8; margin-bottom: 30px; font-size: 1.1rem;">
                ${product.description}
            </p>

            <div style="display: flex; gap: 15px; margin-bottom: 40px;">
                <input type="number" id="qty-input" class="form-control" value="1" min="1" max="${product.stock}" style="width: 80px;" ${isOutOfStock ? 'disabled' : ''}>
                <button id="add-to-cart-btn" class="btn btn-primary" style="flex: 1; font-size: 1.1rem;" ${isOutOfStock ? 'disabled' : ''}>
                    ${isOutOfStock ? 'Out of Stock' : 'Add to Cart'}
                </button>
            </div>

            <div style="border-top: 1px solid var(--border); padding-top: 30px;">
                <h4 style="margin-bottom: 15px;">Store Guarantees</h4>
                <ul style="color: var(--text-muted); padding-left: 20px; list-style-type: disc;">
                    <li style="margin-bottom: 10px;">100% Fresh and Handpicked</li>
                    <li style="margin-bottom: 10px;">Secure Online Payments</li>
                    <li style="margin-bottom: 10px;">Local Neighborhood Delivery</li>
                </ul>
            </div>
        </div>
    `;

    // Attach Add to Cart Event
    const addBtn = document.getElementById('add-to-cart-btn');
    if (addBtn) {
        addBtn.addEventListener('click', () => {
            const qty = parseInt(document.getElementById('qty-input').value) || 1;

            const item = {
                id: product._id,
                name: product.name,
                price: product.basePrice,
                image: product.imageURL,
                quantity: qty
            };

            const cart = getCart();
            const existingIndex = cart.findIndex(cartItem => cartItem.id === item.id);

            if (existingIndex >= 0) {
                cart[existingIndex].quantity += qty;
            } else {
                cart.push(item);
            }

            saveCart(cart);

            const originalText = addBtn.textContent;
            addBtn.textContent = 'Added to Cart!';
            addBtn.classList.replace('btn-primary', 'btn-secondary');

            setTimeout(() => {
                addBtn.textContent = originalText;
                addBtn.classList.replace('btn-secondary', 'btn-primary');
            }, 2000);
        });
    }
}
