document.addEventListener('DOMContentLoaded', () => {
    // If already logged in, redirect to admin
    if (localStorage.getItem('adminToken')) {
        window.location.href = 'admin.html';
    }

    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();

            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const errorDiv = document.getElementById('login-error');

            try {
                const res = await fetch('http://localhost:5000/api/admin/login', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ email, password })
                });

                const data = await res.json();

                if (!res.ok) {
                    throw new Error(data.message || 'Login failed');
                }

                // Save token and role
                localStorage.setItem('adminToken', data.token);
                localStorage.setItem('adminRole', data.role);

                // Redirect to dashboard
                window.location.href = 'admin.html';

            } catch (err) {
                errorDiv.textContent = err.message;
                errorDiv.classList.remove('d-none');
            }
        });
    }
});
