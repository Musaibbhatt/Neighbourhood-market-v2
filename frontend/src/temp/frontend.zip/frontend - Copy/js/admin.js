document.addEventListener('DOMContentLoaded', async () => {
    // 1. Auth check
    const token = localStorage.getItem('adminToken');
    if (!token) {
        window.location.href = 'admin-login.html';
        return;
    }

    // 2. Setup navigation tabs
    const role = localStorage.getItem('adminRole');
    if (role === 'SuperAdmin') {
        document.getElementById('nav-store-mgmt')?.classList.remove('d-none');
        document.getElementById('nav-analytics')?.classList.remove('d-none');
    } else if (role === 'Manager') {
        document.getElementById('nav-analytics')?.classList.remove('d-none');
    }
    setupAdminNav();

    // 3. Setup logout
    document.getElementById('logout-btn')?.addEventListener('click', () => {
        localStorage.removeItem('adminToken');
        localStorage.removeItem('adminRole');
        window.location.href = 'admin-login.html';
    });

    // 4. Initial load (Dashboard Overview)
    await loadOverview();
});

async function loadStoreConfig() {
    try {
        const config = await apiFetch('/store-config');
        document.getElementById('toggle-ordering-enabled').checked = config.orderingEnabled;
        document.getElementById('toggle-delivery-enabled').checked = config.deliveryEnabled;
        document.getElementById('input-free-delivery-threshold').value = config.freeDeliveryThreshold;
        document.getElementById('input-default-delivery-fee').value = config.defaultDeliveryFee || 50;
    } catch (e) {
        console.error('Failed to load store configuration', e);
    }
}

document.getElementById('save-store-config')?.addEventListener('click', async () => {
    const payload = {
        orderingEnabled: document.getElementById('toggle-ordering-enabled').checked,
        deliveryEnabled: document.getElementById('toggle-delivery-enabled').checked,
        freeDeliveryThreshold: parseFloat(document.getElementById('input-free-delivery-threshold').value),
        defaultDeliveryFee: parseFloat(document.getElementById('input-default-delivery-fee').value)
    };

    try {
        await apiFetch('/store-config', { method: 'PUT', body: payload });
        alert('Configuration updated successfully!');
    } catch (e) {
        alert('Failed to update config: ' + e.message);
    }
});

function setupAdminNav() {
    const navLinks = document.querySelectorAll('.admin-nav-link');
    const sections = document.querySelectorAll('.admin-section');

    navLinks.forEach(link => {
        link.addEventListener('click', async (e) => {
            e.preventDefault();

            // UI Active state
            navLinks.forEach(l => l.classList.remove('active'));
            e.currentTarget.classList.add('active');

            // Hide all sections, show target
            const targetId = e.currentTarget.dataset.target;
            sections.forEach(s => s.classList.add('d-none'));
            document.getElementById(targetId).classList.remove('d-none');

            // Load data based on section
            if (targetId === 'overview') await loadOverview();
            if (targetId === 'products') await loadAdminProducts();
            if (targetId === 'categories') await loadAdminCategories();
            if (targetId === 'orders') await loadAdminOrders();
            if (targetId === 'customers') await loadAdminCustomers();
            // subscribers removed
            if (targetId === 'store-mgmt') await loadStoreConfig();
            if (targetId === 'analytics') await loadAnalytics();
            if (targetId === 'reports') await loadAdvancedReports();
            if (targetId === 'activity-log') await loadActivityLog();
        });
    });
}

// =========================================================
// Analytics Section
// =========================================================
let revenueChartInstance = null;
let salesChartInstance = null;

async function loadAnalytics() {
    try {
        const orders = await apiFetch('/orders');

        // 1. Revenue by Date (Last 7 Days)
        const revenueByDate = {};
        const today = new Date();
        for (let i = 0; i < 7; i++) {
            const d = new Date(today);
            d.setDate(d.getDate() - i);
            revenueByDate[d.toLocaleDateString()] = 0;
        }

        orders.forEach(o => {
            if (o.orderStatus !== 'Cancelled') {
                const d = new Date(o.createdAt).toLocaleDateString();
                if (revenueByDate[d] !== undefined) {
                    revenueByDate[d] += o.totalPrice;
                }
            }
        });

        const revLabels = Object.keys(revenueByDate).reverse();
        const revData = Object.values(revenueByDate).reverse();

        if (revenueChartInstance) revenueChartInstance.destroy();
        const ctxRev = document.getElementById('revenueChart').getContext('2d');
        revenueChartInstance = new Chart(ctxRev, {
            type: 'line',
            data: {
                labels: revLabels,
                datasets: [{
                    label: 'Revenue ($)',
                    data: revData,
                    borderColor: '#2c5e3b',
                    backgroundColor: 'rgba(44, 94, 59, 0.1)',
                    fill: true,
                    tension: 0.4
                }]
            }
        });

        // 2. Most Sold Products
        const productSales = {};
        orders.forEach(o => {
            if (o.orderStatus !== 'Cancelled') {
                o.products.forEach(p => {
                    productSales[p.name] = (productSales[p.name] || 0) + p.quantity;
                });
            }
        });

        const sortedProducts = Object.entries(productSales)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 5);

        const salesLabels = sortedProducts.map(p => p[0]);
        const salesData = sortedProducts.map(p => p[1]);

        if (salesChartInstance) salesChartInstance.destroy();
        const ctxSales = document.getElementById('salesChart').getContext('2d');
        salesChartInstance = new Chart(ctxSales, {
            type: 'bar',
            data: {
                labels: salesLabels,
                datasets: [{
                    label: 'Units Sold',
                    data: salesData,
                    backgroundColor: '#e67e22'
                }]
            }
        });

    } catch (e) {
        console.error('Failed to load analytics', e);
    }
}

// =========================================================
// Overview Section
// =========================================================
async function loadOverview() {
    try {
        const [products, orders] = await Promise.all([
            apiFetch('/products'),
            apiFetch('/orders')
        ]);

        document.getElementById('stat-products').textContent = products.length;
        document.getElementById('stat-orders').textContent = orders.length;

        const totalRevenue = orders.filter(o => o.orderStatus !== 'Cancelled').reduce((sum, o) => sum + o.totalPrice, 0);
        document.getElementById('stat-revenue').textContent = formatCurrency(totalRevenue);

        const lowStock = products.filter(p => p.stock < 5).length;
        document.getElementById('stat-lowstock').textContent = lowStock;
        if (lowStock > 0) {
            document.getElementById('stat-lowstock').parentElement.classList.add('warning');
            document.getElementById('badge-lowstock').classList.remove('d-none');
        } else {
            document.getElementById('stat-lowstock').parentElement.classList.remove('warning');
            document.getElementById('badge-lowstock').classList.add('d-none');
        }

        const newOrders = orders.filter(o => o.orderStatus === 'Order Received').length;
        if (newOrders > 0) {
            document.getElementById('badge-neworders').classList.remove('d-none');
        } else {
            document.getElementById('badge-neworders').classList.add('d-none');
        }
    } catch (e) {
        console.error('Failed to load overview data', e);
    }
}

// =========================================================
// Products Section
// =========================================================
async function loadAdminProducts() {
    try {
        const products = await apiFetch('/products');
        const tbody = document.getElementById('admin-products-tbody');
        if (!tbody) return;

        tbody.innerHTML = '';
        products.forEach(p => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td><img src="${p.imageURL || 'images/product_placeholder.svg'}" width="40" height="40" style="object-fit:contain; background:#fff;"></td>
                <td>${p.name}</td>
                <td>${p.category?.name || '-'}</td>
                <td>${formatCurrency(p.basePrice)}</td>
                <td>
                    <span class="badge ${p.stock > 0 ? (p.stock < 5 ? 'badge-error' : (p.stock < 10 ? 'badge-warning' : 'badge-success')) : 'badge-error'}">
                        ${p.stock}
                    </span>
                </td>
                <td>
                    <button class="btn btn-sm btn-outline" onclick="editProduct('${p._id}')">Edit</button>
                    <button class="btn btn-sm btn-outline text-error" onclick="deleteProduct('${p._id}')">Delete</button>
                </td>
            `;
            tbody.appendChild(tr);
        });

        // Also populate categories in the product form select
        const categories = await apiFetch('/categories');
        const select = document.getElementById('product-category');
        if (select) {
            select.innerHTML = '<option value="">Select Category</option>';
            categories.forEach(c => {
                select.innerHTML += `<option value="${c._id}">${c.name}</option>`;
            });
        }
    } catch (e) {
        console.error('Failed to load admin products', e);
    }
}

// Setup Product Form
document.getElementById('form-product')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const id = document.getElementById('product-id').value;
    const isEdit = !!id;

    const category = document.getElementById('product-category').value;
    if (!isEdit && (!category || category === '')) {
        alert('Please select a category');
        return;
    }

    const payload = {
        name: document.getElementById('product-name').value.trim(),
        category: category || undefined,
        basePrice: parseFloat(document.getElementById('product-price').value),
        stock: parseInt(document.getElementById('product-stock').value),
        description: document.getElementById('product-description').value.trim(),
        imageURL: document.getElementById('product-image').value || '',
        salePrice: document.getElementById('product-sale-price').value ? parseFloat(document.getElementById('product-sale-price').value) : null,
        saleExpiresAt: document.getElementById('product-sale-expiry').value || null
    };

    try {
        if (isEdit) {
            await apiFetch(`/products/${id}`, { method: 'PUT', body: payload });
        } else {
            await apiFetch('/products', { method: 'POST', body: payload });
        }

        // Reset and reload
        document.getElementById('form-product').reset();
        document.getElementById('product-id').value = '';
        document.getElementById('product-modal-title').textContent = 'Add Product';
        closeModal('product-modal');
        await loadAdminProducts();
    } catch (e) {
        alert('Error saving product: ' + (e.message || 'Unknown error'));
    }
});

async function deleteProduct(id) {
    if (!confirm('Delete this product?')) return;
    try {
        await apiFetch(`/products/${id}`, { method: 'DELETE' });
        await loadAdminProducts();
    } catch (e) {
        alert('Failed to delete: ' + e.message);
    }
}

window.editProduct = async function (id) {
    try {
        const product = await apiFetch(`/products/${id}`);
        document.getElementById('product-id').value = product._id;
        document.getElementById('product-name').value = product.name;
        document.getElementById('product-category').value = product.category?._id || '';
        document.getElementById('product-price').value = product.basePrice;
        document.getElementById('product-stock').value = product.stock;
        document.getElementById('product-description').value = product.description;
        document.getElementById('product-image').value = product.imageURL;
        document.getElementById('product-sale-price').value = product.salePrice || '';
        if (product.saleExpiresAt) {
            const date = new Date(product.saleExpiresAt);
            const formatted = date.toISOString().slice(0, 16); // format for datetime-local
            document.getElementById('product-sale-expiry').value = formatted;
        } else {
            document.getElementById('product-sale-expiry').value = '';
        }

        document.getElementById('product-modal-title').textContent = 'Edit Product';
        openModal('product-modal');
    } catch (e) {
        alert('Failed to fetch product details.');
    }
}

// =========================================================
// Categories Section
// =========================================================
// =========================================================
// Categories Section
// =========================================================
async function loadAdminCategories() {
    try {
        const categories = await apiFetch('/categories');
        const tbody = document.getElementById('admin-categories-tbody');
        if (!tbody) return;

        tbody.innerHTML = '';
        categories.forEach(c => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td><strong>${c.name}</strong></td>
                <td style="font-size: 0.85rem; color: var(--text-muted);">${c.description || '-'}</td>
                <td>
                    <button class="btn btn-sm btn-outline" onclick="openCategoryModal('${c._id}')">Edit</button>
                    <button class="btn btn-sm btn-outline text-error" onclick="deleteCategory('${c._id}')">Delete</button>
                </td>
            `;
            tbody.appendChild(tr);
        });
    } catch (e) {
        console.error('Failed to load admin categories', e);
    }
}

async function openCategoryModal(id = null) {
    const title = document.getElementById('category-modal-title');
    const form = document.getElementById('form-category');
    form.reset();
    document.getElementById('category-id').value = id || '';

    if (id) {
        title.textContent = 'Edit Category';
        try {
            const categories = await apiFetch('/categories');
            const cat = categories.find(c => c._id === id);
            if (cat) {
                document.getElementById('category-name').value = cat.name;
                document.getElementById('category-description').value = cat.description || '';
            }
        } catch (e) {
            console.error('Failed to fetch category detail');
        }
    } else {
        title.textContent = 'Add New Category';
    }
    openModal('category-modal');
}

window.openCategoryModal = openCategoryModal;

document.getElementById('form-category')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const id = document.getElementById('category-id').value;
    const payload = {
        name: document.getElementById('category-name').value,
        description: document.getElementById('category-description').value
    };

    try {
        const method = id ? 'PUT' : 'POST';
        const url = id ? `/categories/${id}` : '/categories';
        await apiFetch(url, { method, body: payload });

        closeModal('category-modal');
        await loadAdminCategories();
        alert(`Category ${id ? 'updated' : 'added'} successfully!`);
    } catch (e) {
        alert('Error saving category: ' + e.message);
    }
});

async function deleteCategory(id) {
    if (!confirm('Delete this category?')) return;
    try {
        await apiFetch(`/categories/${id}`, { method: 'DELETE' });
        await loadAdminCategories();
    } catch (e) {
        alert('Failed to delete: ' + e.message);
    }
}

window.deleteCategory = deleteCategory;

// =========================================================
// Orders Section
// =========================================================
async function loadAdminOrders() {
    try {
        const orders = await apiFetch('/orders');
        const tbody = document.getElementById('admin-orders-tbody');
        if (!tbody) return;

        tbody.innerHTML = '';
        orders.forEach(o => {
            const d = new Date(o.createdAt).toLocaleDateString();
            const tr = document.createElement('tr');

            let statusBadge = 'badge-secondary';
            if (o.orderStatus === 'Packed') statusBadge = 'badge-warning';
            if (o.orderStatus === 'Out for Delivery') statusBadge = 'badge-primary';
            if (o.orderStatus === 'Delivered') statusBadge = 'badge-success';
            if (o.orderStatus === 'Cancelled') statusBadge = 'badge-error';

            tr.innerHTML = `
                <td>#${o._id.substring(o._id.length - 6).toUpperCase()}</td>
                <td>${o.customerName}</td>
                <td>${formatCurrency(o.totalPrice)}</td>
                <td>${d}</td>
                <td><span class="badge ${statusBadge}">${o.orderStatus}</span></td>
                <td>
                    <button class="btn btn-sm btn-outline" onclick="viewOrder('${o._id}')">View Details</button>
                </td>
            `;
            tbody.appendChild(tr);
        });
    } catch (e) {
        console.error('Failed to load admin orders', e);
    }
}

window.viewOrder = async function (id) {
    try {
        const order = await apiFetch(`/orders/${id}`);

        document.getElementById('view-order-id').textContent = `#${order._id.toUpperCase()}`;
        document.getElementById('view-customer-name').textContent = order.customerName;
        document.getElementById('view-customer-phone').textContent = order.phone;
        document.getElementById('view-customer-address').textContent = order.address;
        document.getElementById('view-order-type').textContent = order.deliveryType;
        document.getElementById('view-payment-method').textContent = order.paymentMethod || 'Cash';
        document.getElementById('view-order-date').textContent = new Date(order.createdAt).toLocaleString();

        // Notes
        const notesContainer = document.getElementById('view-order-notes-container');
        const notesText = document.getElementById('view-order-notes');
        if (order.notes) {
            notesContainer.classList.remove('d-none');
            notesText.textContent = order.notes;
        } else {
            notesContainer.classList.add('d-none');
        }

        // Sumary
        document.getElementById('view-subtotal').textContent = formatCurrency(order.subtotal || 0);
        document.getElementById('view-delivery').textContent = formatCurrency(order.deliveryFee || 0);
        document.getElementById('view-tip').textContent = formatCurrency(order.tipAmount || 0);
        document.getElementById('view-total').textContent = formatCurrency(order.totalPrice);

        // Items
        const itemContainer = document.getElementById('view-order-items');
        itemContainer.innerHTML = '';
        order.products.forEach(item => {
            const div = document.createElement('div');
            div.style.display = 'flex';
            div.style.justifyContent = 'space-between';
            div.innerHTML = `
                <span>${item.name} x ${item.quantity}</span>
                <span style="font-weight: 500;">${formatCurrency(item.price * item.quantity)}</span>
            `;
            itemContainer.appendChild(div);
        });

        // History
        renderOrderHistory(order);

        // Setup status buttons
        const statusBtns = document.querySelectorAll('.status-update-btn');
        statusBtns.forEach(btn => {
            btn.onclick = () => updateStatus(order._id, btn.dataset.status);
            if (btn.dataset.status === order.orderStatus) {
                btn.classList.replace('btn-outline', 'btn-primary');
            } else {
                btn.classList.replace('btn-primary', 'btn-outline');
            }
        });

        // Handle Return Requests
        const returnSection = document.getElementById('admin-return-request');
        if (returnSection) {
            if (order.returnRequest) {
                returnSection.classList.remove('d-none');
                document.getElementById('requested-type-badge').textContent = order.returnRequest.requestType;
                document.getElementById('requested-date').textContent = new Date(order.returnRequest.createdAt).toLocaleDateString();
                document.getElementById('requested-reason').textContent = order.returnRequest.reason;
                document.getElementById('admin-notes-input').value = order.returnRequest.adminNotes || '';

                const approveBtn = document.getElementById('btn-approve-return');
                const rejectBtn = document.getElementById('btn-reject-return');

                approveBtn.onclick = () => updateReturnStatus(order._id, 'Approved');
                rejectBtn.onclick = () => updateReturnStatus(order._id, 'Rejected');

                // If already processed, disable buttons
                if (['Approved', 'Rejected', 'Completed'].includes(order.returnRequest.status)) {
                    approveBtn.disabled = true;
                    rejectBtn.disabled = true;
                    approveBtn.textContent = order.returnRequest.status;
                } else {
                    approveBtn.disabled = false;
                    rejectBtn.disabled = false;
                    approveBtn.textContent = 'Approve Request';
                }
            } else {
                returnSection.classList.add('d-none');
            }
        }

        openModal('order-modal');
    } catch (e) {
        alert('Failed to load order: ' + e.message);
    }
}

async function updateReturnStatus(id, status) {
    try {
        const adminNotes = document.getElementById('admin-notes-input').value;
        await apiFetch(`/orders/${id}/return-status`, {
            method: 'PUT',
            body: { status, adminNotes }
        });
        await viewOrder(id); // Reload modal
        alert(`Return request ${status}`);
    } catch (e) {
        alert('Failed to update return status: ' + e.message);
    }
}

function renderOrderHistory(order) {
    const historyEl = document.getElementById('view-status-history');
    historyEl.innerHTML = '<h5 style="margin-bottom: 5px;">Status History</h5>';
    if (!order.statusHistory || order.statusHistory.length === 0) {
        historyEl.innerHTML += '<p>No history available</p>';
        return;
    }
    order.statusHistory.forEach(h => {
        const time = new Date(h.timestamp).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
        historyEl.innerHTML += `<div style="margin-bottom: 3px;">• ${h.status} <span style="opacity: 0.7">(${time})</span></div>`;
    });
}

async function updateStatus(id, newStatus) {
    try {
        await apiFetch(`/orders/${id}`, {
            method: 'PUT',
            body: { orderStatus: newStatus }
        });
        await viewOrder(id); // Reload modal
        await loadAdminOrders(); // Reload table
    } catch (e) {
        alert('Update failed: ' + e.message);
    }
}

// Order Export CSV
document.getElementById('btn-export-orders')?.addEventListener('click', async () => {
    try {
        const token = localStorage.getItem('adminToken');
        const response = await fetch('/api/orders/export', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (!response.ok) throw new Error('Export failed');

        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `orders_export_${new Date().toISOString().split('T')[0]}.csv`;
        document.body.appendChild(a);
        a.click();
        a.remove();
    } catch (e) {
        alert('Export failed: ' + e.message);
    }
});

// =========================================================
// Simple Modal Wrapper
// =========================================================
function openModal(id) {
    const m = document.getElementById(id);
    if (m) m.classList.remove('d-none');
}
function closeModal(id) {
    const m = document.getElementById(id);
    if (m) m.classList.add('d-none');
}

document.querySelectorAll('.modal-close').forEach(btn => {
    btn.addEventListener('click', (e) => {
        const modal = e.target.closest('.modal-overlay');
        if (modal) modal.classList.add('d-none');
    });
});

// Bulk Stock Tool Logic
document.getElementById('btn-bulk-stock')?.addEventListener('click', () => {
    document.getElementById('bulk-stock-tool').classList.remove('d-none');
});

document.getElementById('btn-cancel-bulk-stock')?.addEventListener('click', () => {
    document.getElementById('bulk-stock-tool').classList.add('d-none');
    document.getElementById('bulk-stock-input').value = '';
});

document.getElementById('btn-submit-bulk-stock')?.addEventListener('click', async () => {
    const input = document.getElementById('bulk-stock-input').value.trim();
    if (!input) return;

    const lines = input.split('\n');
    const updates = lines.map(line => {
        const [id, stock] = line.split(',').map(s => s.trim());
        return { id, stock: parseInt(stock) };
    }).filter(u => u.id && !isNaN(u.stock));

    if (updates.length === 0) {
        alert('Invalid input format. Use: ID, STOCK');
        return;
    }

    try {
        const btn = document.getElementById('btn-submit-bulk-stock');
        btn.disabled = true;
        btn.textContent = 'Updating...';

        await apiFetch('/products/bulk-stock', {
            method: 'POST',
            body: { updates }
        });

        alert('Bulk stock update successful!');
        document.getElementById('bulk-stock-tool').classList.add('d-none');
        document.getElementById('bulk-stock-input').value = '';
        await loadAdminProducts();
    } catch (e) {
        alert('Bulk update failed: ' + e.message);
    } finally {
        const btn = document.getElementById('btn-submit-bulk-stock');
        btn.disabled = false;
        btn.textContent = 'Apply Updates';
    }
});

// =========================================================
// Customers Section
// =========================================================
async function loadAdminCustomers() {
    try {
        const users = await apiFetch('/admin-users');
        const tbody = document.getElementById('admin-customers-tbody');
        if (!tbody) return;

        tbody.innerHTML = '';
        users.forEach(u => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td><strong>${u.name}</strong></td>
                <td>${u.email}</td>
                <td><span class="badge badge-primary">${u.loyaltyPoints || 0}</span></td>
                <td><code style="background:#eee; padding:2px 5px; border-radius:4px;">${u.referralCode || '-'}</code></td>
                <td>${new Date(u.createdAt).toLocaleDateString()}</td>
                <td>
                    <button class="btn btn-sm btn-outline" onclick="editCustomer('${u._id}')">Edit</button>
                </td>
            `;
            tbody.appendChild(tr);
        });
    } catch (e) {
        console.error('Failed to load customers', e);
    }
}

window.editCustomer = async function (id) {
    try {
        const users = await apiFetch('/admin-users');
        const user = users.find(u => u._id === id);
        if (!user) return;

        document.getElementById('customer-id').value = user._id;
        document.getElementById('customer-name').value = user.name;
        document.getElementById('customer-points').value = user.loyaltyPoints || 0;

        openModal('customer-modal');
    } catch (e) {
        alert('Failed to fetch customer details');
    }
}

document.getElementById('form-customer')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const id = document.getElementById('customer-id').value;
    const payload = {
        name: document.getElementById('customer-name').value,
        loyaltyPoints: parseInt(document.getElementById('customer-points').value)
    };

    try {
        await apiFetch(`/admin-users/${id}`, { method: 'PUT', body: payload });
        alert('Customer updated successfully!');
        closeModal('customer-modal');
        await loadAdminCustomers();
    } catch (e) {
        alert('Error updating customer: ' + e.message);
    }
});
// Subscribers feature removed

// =========================================================
// Phase 17: Activity Log & Advanced Reports
// =========================================================

/**
 * Log administrative activity (stored in localStorage for now)
 */
function logActivity(action, details = '') {
    const logs = JSON.parse(localStorage.getItem('admin_activity_logs') || '[]');
    const newLog = {
        timestamp: new Date().toISOString(),
        admin: localStorage.getItem('adminEmail') || 'Admin',
        action,
        details
    };
    logs.unshift(newLog);
    // Keep only last 100 logs
    localStorage.setItem('admin_activity_logs', JSON.stringify(logs.slice(0, 100)));
}

async function loadActivityLog() {
    const tbody = document.getElementById('admin-log-tbody');
    if (!tbody) return;

    const logs = JSON.parse(localStorage.getItem('admin_activity_logs') || '[]');
    tbody.innerHTML = '';

    if (logs.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;">No activities logged yet.</td></tr>';
        return;
    }

    logs.forEach(log => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td><small>${new Date(log.timestamp).toLocaleString()}</small></td>
            <td>${log.admin}</td>
            <td><span class="badge badge-primary" style="font-size:0.75rem">${log.action}</span></td>
            <td style="font-size:0.85rem">${log.details}</td>
        `;
        tbody.appendChild(tr);
    });

    // Dashboard mini log
    const miniLog = document.getElementById('dashboard-activity-mini');
    if (miniLog) {
        miniLog.innerHTML = logs.slice(0, 5).map(log => `
            <div style="margin-bottom:8px; display:flex; justify-content:space-between;">
                <span>${log.action}</span>
                <small>${new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</small>
            </div>
        `).join('');
    }
}

document.getElementById('btn-clear-log')?.addEventListener('click', () => {
    if (confirm('Clear all activity logs?')) {
        localStorage.removeItem('admin_activity_logs');
        loadActivityLog();
    }
});

let categoryRevenueChart = null;
let monthlyGrowthChart = null;

async function loadAdvancedReports() {
    try {
        const [orders, products] = await Promise.all([
            apiFetch('/orders'),
            apiFetch('/products')
        ]);

        const validOrders = orders.filter(o => o.orderStatus !== 'Cancelled');

        // 1. Revenue by Category
        const catRev = {};
        validOrders.forEach(o => {
            o.products.forEach(p => {
                const catName = p.category?.name || 'Uncategorized';
                catRev[catName] = (catRev[catName] || 0) + (p.price * p.quantity);
            });
        });

        if (categoryRevenueChart) categoryRevenueChart.destroy();
        const ctx1 = document.getElementById('chart-category-revenue').getContext('2d');
        categoryRevenueChart = new Chart(ctx1, {
            type: 'pie',
            data: {
                labels: Object.keys(catRev),
                datasets: [{
                    data: Object.values(catRev),
                    backgroundColor: ['#2c5e3b', '#e67e22', '#3498db', '#9b59b6', '#f1c40f', '#e74c3c']
                }]
            },
            options: { responsive: true, plugins: { legend: { position: 'bottom' } } }
        });

        // 2. Monthly Growth (Simulated over last 6 months)
        const months = ['Oct', 'Nov', 'Dec', 'Jan', 'Feb', 'Mar'];
        const growthData = [1200, 1900, 1700, 2400, 2800, 3200];

        if (monthlyGrowthChart) monthlyGrowthChart.destroy();
        const ctx2 = document.getElementById('chart-monthly-growth').getContext('2d');
        monthlyGrowthChart = new Chart(ctx2, {
            type: 'line',
            data: {
                labels: months,
                datasets: [{
                    label: 'Gross Sales ($)',
                    data: growthData,
                    borderColor: '#e67e22',
                    tension: 0.3,
                    fill: false
                }]
            }
        });

    } catch (e) {
        console.error('Failed to load advanced reports', e);
    }
}

// Hook into existing actions for logging
function setupActionLogging() {
    const productForm = document.getElementById('form-product');
    if (productForm) {
        productForm.addEventListener('submit', () => {
            const id = document.getElementById('product-id').value;
            logActivity(id ? 'Product Updated' : 'Product Created', document.getElementById('product-name').value);
        });
    }

    const categoryForm = document.getElementById('form-category');
    if (categoryForm) {
        categoryForm.addEventListener('submit', () => {
            const id = document.getElementById('category-id').value;
            logActivity(id ? 'Category Updated' : 'Category Created', document.getElementById('category-name').value);
        });
    }
}

setupActionLogging();

async function wrappedUpdateStatus(id, newStatus) {
    await updateStatus(id, newStatus);
    logActivity('Order Status Update', `Order ${id.substring(id.length - 10).toUpperCase()} -> ${newStatus}`);
}
// Replace global updateStatus for logging
window.updateStatus = wrappedUpdateStatus;
