// Global Variables
let currentProducts = [];
let dbCategories = [];
let userWishlist = [];

document.addEventListener('DOMContentLoaded', async () => {
    // 1. Check URL parameters
    const urlParams = new URLSearchParams(window.location.search);
    const initialSearch = urlParams.get('search') || '';
    const initialCategory = urlParams.get('category') || '';

    if (initialSearch) {
        const searchInput = document.getElementById('search-input');
        if (searchInput) searchInput.value = initialSearch;
    }

    // 2. Fetch data for filters
    await loadCategories();
    await loadBrands();
    if (localStorage.getItem('token')) {
        await fetchWishlist();
    }

    // 3. Fetch and render products initially
    await loadProducts(initialCategory, initialSearch);

    // 4. Setup event listeners
    setupFilters();
    setupSearch();
    setupSort();
    setupAdvancedFilters();

    // 5. Load recently viewed products
    if (localStorage.getItem('userToken')) {
        await loadRecentlyViewedProducts();
    }
});

async function loadCategories() {
    try {
        dbCategories = await apiFetch('/categories');
        const sidebarContainer = document.getElementById('category-filter-sidebar');

        if (!sidebarContainer) return;

        dbCategories.forEach(cat => {
            const btn = document.createElement('button');
            btn.className = 'filter-link';
            btn.dataset.category = cat._id;
            btn.textContent = cat.name;
            sidebarContainer.appendChild(btn);
        });
    } catch (e) {
        console.error('Failed to load categories', e);
    }
}

async function loadBrands() {
    try {
        const brands = await apiFetch('/products/brands');
        const brandContainer = document.getElementById('brand-filter-sidebar');
        if (!brandContainer) return;

        brands.forEach(brand => {
            const btn = document.createElement('button');
            btn.className = 'filter-link';
            btn.dataset.brand = brand;
            btn.textContent = brand;
            brandContainer.appendChild(btn);
        });
    } catch (e) {
        console.error('Failed to load brands', e);
    }
}

async function fetchWishlist() {
    try {
        const wishlist = await apiFetch('/users/wishlist');
        userWishlist = wishlist.map(p => p._id);
    } catch (err) {
        console.error('Failed to fetch wishlist:', err);
    }
}

async function toggleWishlist(productId) {
    if (!localStorage.getItem('userToken')) {
        alert('Please login to add items to your wishlist!');
        window.location.href = 'login.html?redirect=shop.html';
        return;
    }

    try {
        const updatedWishlist = await apiFetch(`/users/wishlist/toggle/${productId}`, {
            method: 'POST'
        });
        userWishlist = updatedWishlist;
        renderProducts(currentProducts);
    } catch (err) {
        console.error('Failed to toggle wishlist:', err);
    }
}

async function loadProducts(categoryId = '', search = '', filters = {}) {
    try {
        const grid = document.getElementById('product-grid');
        if (!grid) return;

        // Phase 16: Use Skeleton Loaders
        renderSkeleton(grid, 8);

        const params = new URLSearchParams();
        if (categoryId) params.append('category', categoryId);
        if (search) params.append('search', search);

        // Add advanced filters
        Object.keys(filters).forEach(key => {
            if (filters[key]) params.append(key, filters[key]);
        });

        const url = params.toString() ? `/products?${params.toString()}` : '/products';
        currentProducts = await apiFetch(url);

        renderProducts(currentProducts);
    } catch (e) {
        console.error('Failed to load products', e);
        const grid = document.getElementById('product-grid');
        if (grid) grid.innerHTML = '<p class="text-error text-center" style="grid-column: 1/-1;">Failed to load products.</p>';
    }
}

function renderProducts(products) {
    const grid = document.getElementById('product-grid');
    if (!grid) return;

    if (products.length === 0) {
        grid.innerHTML = '<div style="grid-column: 1 / -1;" class="text-center"><p>No products found.</p></div>';
        return;
    }

    grid.innerHTML = '';
    const cart = getCart();

    products.forEach(product => {
        const card = document.createElement('div');
        card.className = 'card product-card';

        const imgSrc = product.imageURL || 'images/product_placeholder.svg';

        // Flash Sale logic
        const now = new Date();
        const isOnSale = product.salePrice && product.saleExpiresAt && new Date(product.saleExpiresAt) > now;
        const displayPrice = isOnSale ? product.salePrice : product.basePrice;
        const priceDisplay = formatCurrency(displayPrice);
        const originalPriceDisplay = isOnSale ? `<span style="text-decoration: line-through; color: #999; font-size: 0.9rem; margin-left: 5px;">${formatCurrency(product.basePrice)}</span>` : '';

        let saleBadge = '';
        let countdownHtml = '';
        if (isOnSale) {
            saleBadge = '<span class="badge" style="position: absolute; top: 10px; left: 10px; background: #f44336; color: white;">FLASH SALE</span>';
            countdownHtml = `<div class="sale-countdown" data-expire="${product.saleExpiresAt}" style="font-size: 0.75rem; color: #f44336; font-weight: 600; margin-top: 5px;"></div>`;
        }

        // Phase 16: Stock Badge fix (was missing definition)
        let stockBadge = '';
        if (product.stock <= 0) {
            stockBadge = '<span class="badge badge-error" style="position: absolute; top: 10px; right: 10px;">OUT OF STOCK</span>';
        } else if (product.stock <= 5) {
            stockBadge = `<span class="badge badge-warning" style="position: absolute; top: 10px; right: 10px;">ONLY ${product.stock} LEFT</span>`;
        }

        // Check if in cart
        const cartItem = cart.find(item => item.id === product._id);
        const isInWishlist = userWishlist.includes(product._id);

        card.innerHTML = `
            <div style="position: relative; padding: 20px; text-align: center; background: #f9f9f9;">
                ${stockBadge}
                ${saleBadge}
                <button class="wishlist-btn ${isInWishlist ? 'active' : ''}" 
                        onclick="toggleWishlist('${product._id}')" 
                        title="${isInWishlist ? 'Remove from Wishlist' : 'Add to Wishlist'}">
                    <svg width="20" height="20" fill="${isInWishlist ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                        <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
                    </svg>
                </button>
                <img src="${imgSrc}" alt="${product.name}" loading="lazy" style="height: 180px; object-fit: contain; margin: 0 auto;">
            </div>
            <div style="padding: 20px;">
                <p class="text-muted" style="font-size: 0.85rem; margin-bottom: 5px;">${product.brand || ''} ${product.brand ? '•' : ''} ${product.category?.name || 'Uncategorized'}</p>
                <h3 style="font-size: 1.1rem; margin-bottom: 5px; min-height: 2.4em;">
                    <a href="#" class="view-product-details" data-id="${product._id}">${product.name}</a>
                </h3>
                
                <div style="display: flex; align-items: center; gap: 5px; margin-bottom: 10px; font-size: 0.9rem;">
                    <div style="color: #ffc107;">
                        ${Array.from({ length: 5 }, (_, i) => `<span style="${i < Math.round(product.averageRating || 0) ? 'color: #ffc107;' : 'color: #ccc;'}">★</span>`).join('')}
                    </div>
                    <span class="text-muted">(${product.numReviews || 0})</span>
                </div>

                <div style="margin-bottom: 10px; display: flex; flex-wrap: wrap; gap: 4px;">
                    ${product.isOrganic ? '<span class="badge badge-dietary organic">Organic</span>' : ''}
                    ${product.isVegan ? '<span class="badge badge-dietary vegan">Vegan</span>' : ''}
                    ${product.isGlutenFree ? '<span class="badge badge-dietary gluten-free">Gluten-Free</span>' : ''}
                </div>

                <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-top: 15px;">
                    <div>
                        <span style="font-weight: 700; font-size: 1.2rem; color: var(--primary);">${priceDisplay}</span>
                        ${originalPriceDisplay}
                        ${countdownHtml}
                    </div>
                    
                    <div class="product-action-container" id="action-${product._id}" data-product-id="${product._id}">
                        ${product.stock > 0 ? (
                cartItem ? renderStepperHtml(product._id, cartItem.quantity) : `
                                <div style="display: flex; flex-direction: column; gap: 8px;">
                                    <button class="btn btn-primary btn-add-cart" 
                                        data-id="${product._id}" 
                                        data-name="${product.name}" 
                                        data-price="${displayPrice}"
                                        data-img="${imgSrc}">
                                        Add to Cart
                                    </button>
                                    <button class="btn btn-buy-now" 
                                        onclick="handleBuyNow('${product._id}', '${product.name}', ${displayPrice}, '${imgSrc}')">
                                        Buy Now
                                    </button>
                                </div>
                            `
            ) : `
                            <button class="btn btn-notify" onclick="requestStockNotification('${product._id}')">
                                Notify Me
                            </button>
                        `}
                    </div>
                </div>
            </div>
        `;

        grid.appendChild(card);
    });

    // Attach cart event listeners
    attachActionListeners();
    startCountdowns();
}

function renderStepperHtml(productId, quantity) {
    return `
        <div class="quantity-stepper">
            <button class="stepper-btn minus" data-id="${productId}">-</button>
            <input type="number" class="stepper-input" value="${quantity}" readonly>
            <button class="stepper-btn plus" data-id="${productId}">+</button>
        </div>
    `;
}

function attachActionListeners() {
    document.querySelectorAll('.btn-add-cart').forEach(btn => {
        btn.addEventListener('click', handleAddToCart);
    });
    document.querySelectorAll('.stepper-btn.plus').forEach(btn => {
        btn.addEventListener('click', () => updateCartQuantity(btn.dataset.id, 1));
    });
    document.querySelectorAll('.stepper-btn.minus').forEach(btn => {
        btn.addEventListener('click', () => updateCartQuantity(btn.dataset.id, -1));
    });
    document.querySelectorAll('.view-product-details').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            openProductModal(link.dataset.id);
        });
    });
}
async function openProductModal(productId) {
    try {
        const product = await apiFetch(`/products/${productId}`);
        const modal = document.getElementById('product-modal');
        const details = document.getElementById('product-modal-details');

        // Track view
        trackProductView(productId);

        // SEO: Update Title
        document.title = `${product.name} - Neighbourhood Market`;

        const now = new Date();
        const isOnSale = product.salePrice && product.saleExpiresAt && new Date(product.saleExpiresAt) > now;
        const displayPrice = isOnSale ? product.salePrice : product.basePrice;

        details.innerHTML = `
            <div class="grid grid-cols-2" style="gap: 30px;">
                <div style="background: #f9f9f9; border-radius: 8px; padding: 20px; display: flex; align-items: center; position: relative;">
                    ${isOnSale ? '<span class="badge" style="position: absolute; top: 10px; left: 10px; background: #f44336; color: white; padding: 5px 10px;">FLASH SALE</span>' : ''}
                    <img src="${product.imageURL || 'images/product_placeholder.svg'}" style="width: 100%; max-height: 300px; object-fit: contain;">
                </div>
                <div>
                    <p class="text-muted">${product.brand || ''} • ${product.category?.name}</p>
                    <h2 style="margin-bottom: 5px;">${product.name}</h2>
                    <div style="margin-bottom: 10px;">
                        <h3 style="color: var(--primary); display: inline-block; margin-right: 10px;">${formatCurrency(displayPrice)}</h3>
                        ${isOnSale ? `<span style="text-decoration: line-through; color: #999;">${formatCurrency(product.basePrice)}</span>` : ''}
                        ${isOnSale ? `<div class="sale-countdown" data-expire="${product.saleExpiresAt}" style="color: #f44336; font-weight: 600; margin-top: 5px; font-size: 0.9rem;"></div>` : ''}
                    </div>
                    
                    <div style="margin-bottom: 15px; display: flex; flex-wrap: wrap; gap: 5px;">
                        ${product.isOrganic ? '<span class="badge badge-dietary organic">Organic</span>' : ''}
                        ${product.isVegan ? '<span class="badge badge-dietary vegan">Vegan</span>' : ''}
                        ${product.isGlutenFree ? '<span class="badge badge-dietary gluten-free">Gluten-Free</span>' : ''}
                    </div>

                    <p style="margin-bottom: 20px; line-height: 1.6;">${product.description || 'No description available for this product.'}</p>
                    <p style="margin-bottom: 20px; font-weight: 500;">
                        Stock: <span class="${product.stock > 0 ? 'text-success' : 'text-error'}">${product.stock > 0 ? product.stock + ' units available' : 'Out of Stock'}</span>
                    </p>
                    <div id="modal-action-${product._id}" style="margin-bottom: 25px;">
                        <button class="btn btn-primary btn-block" onclick="handleAddToCartFromModal('${product._id}', '${product.name}', ${displayPrice}, '${product.imageURL || 'images/product_placeholder.svg'}')">Add to Cart</button>
                    </div>

                    <div class="social-share-container">
                        <a href="https://wa.me/?text=${productTitle}%20${productUrl}" target="_blank" class="btn-social btn-whatsapp">
                            <svg width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><path d="M13.601 2.326A7.854 7.854 0 0 0 7.994 0C3.627 0 .068 3.558.064 7.926c0 1.399.366 2.76 1.057 3.965L0 16l4.204-1.102a7.933 7.933 0 0 0 3.79.965h.004c4.368 0 7.926-3.558 7.93-7.93A7.898 7.898 0 0 0 13.6 2.326zM7.994 14.521a6.573 6.573 0 0 1-3.356-.92l-.24-.144-2.494.654.666-2.433-.156-.251a6.56 6.56 0 0 1-1.007-3.505c0-3.626 2.957-6.584 6.591-6.584a6.56 6.56 0 0 1 4.66 1.931 6.557 6.557 0 0 1 1.928 4.66c-.004 3.639-2.961 6.592-6.592 6.592zm3.615-4.934c-.197-.099-1.17-.578-1.353-.646-.182-.065-.315-.099-.445.099-.133.197-.513.646-.627.775-.114.133-.232.148-.43.05-.197-.1-.836-.308-1.592-.985-.59-.525-.985-1.175-1.103-1.372-.114-.198-.011-.304.088-.403.087-.088.197-.232.296-.346.1-.114.133-.198.198-.33.065-.134.034-.248-.015-.347-.05-.099-.445-1.076-.612-1.47-.16-.389-.323-.335-.445-.34-.114-.007-.247-.007-.38-.007a.729.729 0 0 0-.529.247c-.182.198-.691.677-.691 1.654 0 .977.71 1.916.81 2.049.098.133 1.394 2.132 3.383 2.992.47.205.84.326 1.129.418.475.152.904.129 1.246.08.38-.058 1.171-.48 1.338-.943.164-.464.164-.86.114-.943-.049-.084-.182-.133-.38-.232z"/></svg> 
                            WhatsApp
                        </a>
                        <a href="https://twitter.com/intent/tweet?text=${productTitle}&url=${productUrl}" target="_blank" class="btn-social btn-twitter">
                            <svg width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><path d="M12.6.75h2.454l-5.36 6.142L16 15.25h-4.937l-3.867-5.055-4.425 5.055H.316l5.733-6.57L0 .75h5.063l3.495 4.633L12.601.75Zm-.86 13.028h1.36L4.323 2.145H2.865l8.875 11.633Z"/></svg>
                            X
                        </a>
                        <a href="https://www.instagram.com/" target="_blank" class="btn-social btn-instagram">
                            <svg width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><path d="M8 0C5.829 0 5.556.01 4.703.048 3.85.088 3.269.222 2.76.42a3.917 3.917 0 0 0-1.417.923A3.927 3.927 0 0 0 .42 2.76C.222 3.268.087 3.85.048 4.7.01 5.555 0 5.827 0 8.001c0 2.172.01 2.444.048 3.297.04.852.174 1.433.372 1.942.205.526.478.972.923 1.417.444.445.89.719 1.416.923.51.198 1.09.333 1.942.372C5.555 15.99 5.827 16 8 16s2.444-.01 3.298-.048c.851-.04 1.434-.174 1.943-.372a3.916 3.916 0 0 0 1.416-.923c.445-.445.718-.891.923-1.417.197-.509.332-1.09.372-1.942C15.99 10.445 16 10.173 16 8s-.01-2.445-.048-3.299c-.04-.851-.175-1.433-.372-1.941a3.926 3.926 0 0 0-.923-1.417A3.911 3.911 0 0 0 13.24.42c-.51-.198-1.092-.333-1.943-.372C10.443.01 10.172 0 7.998 0h.003zm-.717 1.442h.718c2.136 0 2.389.007 3.232.046.78.035 1.204.166 1.486.275.373.145.64.319.92.599.28.28.453.546.598.92.11.281.24.705.275 1.485.039.843.047 1.096.047 3.231s-.008 2.389-.047 3.232c-.035.78-.166 1.203-.275 1.485a2.47 2.47 0 0 1-.599.919c-.28.28-.546.453-.92.598-.28.11-.704.24-1.485.276-.843.038-1.096.047-3.232.047s-2.39-.009-3.233-.047c-.78-.036-1.203-.166-1.485-.276a2.478 2.478 0 0 1-.92-.598 2.48 2.48 0 0 1-.6-.92c-.109-.281-.24-.705-.275-1.485-.038-.843-.046-1.096-.046-3.233 0-2.136.008-2.388.046-3.231.036-.78.166-1.204.276-1.486.145-.373.319-.64.599-.92.28-.28.546-.453.92-.598.282-.11.705-.24 1.485-.276.738-.034 1.024-.044 2.515-.045v.002zm4.988 1.328a.96.96 0 1 0 0 1.92.96.96 0 0 0 0-1.92zm-4.27 1.122a4.109 4.109 0 1 0 0 8.217 4.109 4.109 0 0 0 0-8.217zm0 1.441a2.667 2.667 0 1 1 0 5.334 2.667 2.667 0 0 1 0-5.334z"/></svg>
                            Instagram
                        </a>
                    </div>
                </div>
            </div>

            <div id="related-products-section" style="margin-top: 40px; border-top: 1px solid var(--border); padding-top: 20px;">
                <h3 style="margin-bottom: 20px;">People also bought</h3>
                <div id="related-products-grid" class="grid grid-cols-4" style="gap: 15px;">
                    <p class="text-center" style="grid-column: 1/-1;">Loading recommendations...</p>
                </div>
            </div>
        `;

        modal.classList.remove('d-none');
        await loadRelatedProducts(productId);
        await loadReviews(productId);
        setupReviewForm(productId);
    } catch (e) {
        console.error(e);
        alert('Failed to load product details');
    }
}

async function loadRelatedProducts(productId) {
    const container = document.getElementById('related-products-grid');
    if (!container) return;

    try {
        const related = await apiFetch(`/products/${productId}/related`);
        if (related.length === 0) {
            document.getElementById('related-products-section').classList.add('d-none');
            return;
        }

        container.innerHTML = related.map(p => `
            <div class="card" style="padding: 10px; text-align: center; cursor: pointer;" onclick="openProductModal('${p._id}')">
                <img src="${p.imageURL || 'images/product_placeholder.svg'}" style="height: 100px; object-fit: contain; margin-bottom: 8px;">
                <h4 style="font-size: 0.85rem; margin-bottom: 5px; min-height: 2.4em;">${p.name}</h4>
                <p style="color: var(--primary); font-weight: 700; font-size: 0.9rem;">${formatCurrency(p.basePrice)}</p>
            </div>
        `).join('');
    } catch (e) {
        container.innerHTML = '<p class="text-error">Failed to load recommendations.</p>';
    }
}

window.closeProductModal = function () {
    document.getElementById('product-modal').classList.add('d-none');
    document.title = 'Shop - Neighbourhood Market';
}

async function loadReviews(productId) {
    const container = document.getElementById('reviews-container');
    container.innerHTML = '<p class="text-center">Loading reviews...</p>';

    try {
        const reviews = await apiFetch(`/products/${productId}/reviews`);
        if (reviews.length === 0) {
            container.innerHTML = '<p class="text-center text-muted" style="padding: 20px;">No reviews yet. Be the first to review!</p>';
            return;
        }

        container.innerHTML = reviews.map(r => `
            <div class="review-item">
                <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                    <strong style="font-size: 0.95rem;">${r.user?.name || 'Customer'}</strong>
                    <div style="color: #ffc107; font-size: 0.85rem;">
                        ${'★'.repeat(r.rating)}${'☆'.repeat(5 - r.rating)}
                    </div>
                </div>
                <p style="font-size: 0.9rem; line-height: 1.5; color: #555;">${r.comment}</p>
                ${r.imageUrl ? `<img src="${r.imageUrl}" alt="Review photo" style="max-height: 150px; max-width: 100%; border-radius: 8px; margin: 10px 0; display: block; cursor: pointer; border: 1px solid var(--border);" onclick="window.open('${r.imageUrl}', '_blank')">` : ''}
                <small class="text-muted">${new Date(r.createdAt).toLocaleDateString()}</small>
            </div>
        `).join('');
    } catch (e) {
        container.innerHTML = '<p class="text-error">Failed to load reviews.</p>';
    }
}

function setupReviewForm(productId) {
    const isLogged = !!localStorage.getItem('userToken');
    const formContainer = document.getElementById('review-form-container');
    const loginPrompt = document.getElementById('login-to-review');

    if (isLogged) {
        formContainer.classList.remove('d-none');
        loginPrompt.classList.add('d-none');

        // Star selector
        const stars = document.querySelectorAll('#star-selector .star');
        const ratingInput = document.getElementById('review-rating');

        const updateStars = (val) => {
            stars.forEach((s, i) => {
                if (i < val) s.classList.add('active');
                else s.classList.remove('active');
            });
        };

        updateStars(5); // default

        stars.forEach(s => {
            s.onclick = () => {
                const val = parseInt(s.dataset.value);
                ratingInput.value = val;
                updateStars(val);
            };
        });

        document.getElementById('review-form').onsubmit = async (e) => {
            e.preventDefault();
            const payload = {
                rating: ratingInput.value,
                comment: document.getElementById('review-comment').value,
                imageUrl: document.getElementById('review-image').value.trim()
            };

            try {
                await apiFetch(`/products/${productId}/reviews`, { method: 'POST', body: payload });
                alert('Review submitted successfully!');
                document.getElementById('review-comment').value = '';
                document.getElementById('review-image').value = '';
                await loadReviews(productId);
            } catch (err) {
                alert(err.message);
            }
        };
    } else {
        formContainer.classList.add('d-none');
        loginPrompt.classList.remove('d-none');
    }
}

window.handleAddToCartFromModal = (id, name, price, img) => {
    const item = { id, name, price, image: img, quantity: 1 };
    const cart = getCart();
    const existing = cart.find(i => i.id === id);
    if (existing) existing.quantity++;
    else cart.push(item);

    saveCart(cart);
    updateCartIcon();
    playSound('cart-add');
    alert('Added to cart!');
};

window.handleBuyNow = (id, name, price, img) => {
    const item = { id, name, price, image: img, quantity: 1 };
    const cart = getCart();
    const existing = cart.find(i => i.id === id);
    if (!existing) cart.push(item);

    saveCart(cart);
    updateCartIcon();
    playSound('success');
    window.location.href = 'checkout.html';
};

function handleAddToCart(e) {
    const btn = e.currentTarget;
    const productId = btn.dataset.id;
    const item = {
        id: productId,
        name: btn.dataset.name,
        price: parseFloat(btn.dataset.price),
        image: btn.dataset.img,
        quantity: 1
    };

    const cart = getCart();
    cart.push(item);
    saveCart(cart);
    updateCartIcon();
    playSound('cart-add');

    // Swap button for stepper
    const container = document.getElementById(`action-${productId}`);
    if (container) {
        container.innerHTML = renderStepperHtml(productId, 1);
        attachActionListeners();
    }
}

function updateCartQuantity(productId, change) {
    const cart = getCart();
    const index = cart.findIndex(item => item.id === productId);

    if (index >= 0) {
        cart[index].quantity += change;

        if (cart[index].quantity <= 0) {
            cart.splice(index, 1);
            // Re-render "Add to Cart" button
            const container = document.getElementById(`action-${productId}`);
            if (container) {
                // We need to find the product data to rebuild the button
                const product = currentProducts.find(p => p._id === productId);
                if (product) {
                    const priceDisplay = formatCurrency(product.basePrice);
                    container.innerHTML = `
                        <button class="btn btn-primary btn-add-cart" 
                            data-id="${product._id}" 
                            data-name="${product.name}" 
                            data-price="${product.basePrice}"
                            data-img="${product.imageURL || 'images/product_placeholder.svg'}">
                            Add to Cart
                        </button>
                    `;
                    attachActionListeners();
                }
            }
        } else {
            // Update stepper input value
            const container = document.getElementById(`action-${productId}`);
            if (container) {
                const input = container.querySelector('.stepper-input');
                if (input) input.value = cart[index].quantity;
            }
        }

        saveCart(cart);
        updateCartIcon();
    }
}

function setupFilters() {
    const sidebar = document.querySelector('.shop-sidebar');
    if (!sidebar) return;

    sidebar.addEventListener('click', async (e) => {
        const link = e.target.closest('.filter-link');
        if (link) {
            // Update active state in its section
            const parent = link.parentElement;
            parent.querySelectorAll('.filter-link').forEach(l => l.classList.remove('active'));
            link.classList.add('active');

            await applyAdvancedFilters();
        }
    });
}

function setupAdvancedFilters() {
    // Checkboxes
    ['filter-organic', 'filter-gluten-free', 'filter-vegan'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.addEventListener('change', applyAdvancedFilters);
    });

    // Price
    const priceBtn = document.getElementById('apply-price-filter');
    if (priceBtn) priceBtn.addEventListener('click', applyAdvancedFilters);
}

async function applyAdvancedFilters() {
    const activeCatLink = document.querySelector('#category-filter-sidebar .filter-link.active');
    const activeBrandLink = document.querySelector('#brand-filter-sidebar .filter-link.active');

    const categoryId = activeCatLink ? activeCatLink.dataset.category : '';
    const brand = activeBrandLink ? activeBrandLink.dataset.brand : '';
    const search = document.getElementById('search-input')?.value || '';

    const filters = {
        brand: brand,
        isOrganic: document.getElementById('filter-organic')?.checked,
        isGlutenFree: document.getElementById('filter-gluten-free')?.checked,
        isVegan: document.getElementById('filter-vegan')?.checked,
        minPrice: document.getElementById('price-min')?.value,
        maxPrice: document.getElementById('price-max')?.value
    };

    await loadProducts(categoryId, search, filters);
}

function setupSearch() {
    const searchInput = document.getElementById('search-input');
    const searchBtn = document.getElementById('search-btn');

    if (searchBtn && searchInput) {
        searchBtn.addEventListener('click', applyAdvancedFilters);
        searchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') applyAdvancedFilters();
        });
    }
}

function setupSort() {
    const sortSelect = document.getElementById('sort-select');
    if (!sortSelect) return;

    sortSelect.addEventListener('change', (e) => {
        const value = e.target.value;
        const sorted = [...currentProducts];

        if (value === 'price-asc') {
            sorted.sort((a, b) => a.basePrice - b.basePrice);
        } else if (value === 'price-desc') {
            sorted.sort((a, b) => b.basePrice - a.basePrice);
        } else if (value === 'name-asc') {
            sorted.sort((a, b) => a.name.localeCompare(b.name));
        }

        renderProducts(sorted);
    });
}
async function requestStockNotification(productId) {
    if (!localStorage.getItem('userToken')) {
        alert('Please login to request stock alerts!');
        window.location.href = 'login.html?redirect=shop.html';
        return;
    }

    try {
        const result = await apiFetch(`/products/${productId}/stock-notify`, {
            method: 'POST'
        });
        alert(result.message);
    } catch (err) {
        alert(err.message || 'Failed to request notification.');
    }
}

let countdownInterval = null;
function startCountdowns() {
    if (countdownInterval) clearInterval(countdownInterval);

    const updateTimers = () => {
        const timers = document.querySelectorAll('.sale-countdown');
        const now = new Date().getTime();

        timers.forEach(timer => {
            const expire = new Date(timer.dataset.expire).getTime();
            const distance = expire - now;

            if (distance < 0) {
                timer.textContent = "SALE ENDED";
                timer.style.color = "#999";
                return;
            }

            const h = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const m = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            const s = Math.floor((distance % (1000 * 60)) / 1000);

            timer.textContent = `Ends in: ${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
        });
    };

    updateTimers();
    countdownInterval = setInterval(updateTimers, 1000);
}

async function trackProductView(productId) {
    if (!localStorage.getItem('userToken')) return;
    try {
        await apiFetch('/users/recently-viewed', {
            method: 'POST',
            body: { productId }
        });
        loadRecentlyViewedProducts(); // Refresh bottom section
    } catch (err) {
        console.error('Failed to track view:', err);
    }
}

async function loadRecentlyViewedProducts() {
    const container = document.getElementById('recently-viewed-grid');
    const section = document.getElementById('section-recently-viewed');
    if (!container || !section) return;

    try {
        const products = await apiFetch('/users/recently-viewed');
        if (products.length === 0) {
            section.classList.add('d-none');
            return;
        }

        section.classList.remove('d-none');
        container.innerHTML = products.map(p => `
            <div class="card" style="padding: 15px; text-align: center; cursor: pointer;" onclick="openProductModal('${p._id}')">
                <img src="${p.imageURL || 'images/product_placeholder.svg'}" style="height: 120px; object-fit: contain; margin-bottom: 10px;">
                <h4 style="font-size: 0.9rem; margin-bottom: 5px; min-height: 2.4em;">${p.name}</h4>
                <p style="color: var(--primary); font-weight: 700; font-size: 1rem;">${formatCurrency(p.basePrice)}</p>
            </div>
        `).join('');
    } catch (err) {
        console.error('Failed to load recently viewed:', err);
        section.classList.add('d-none');
    }
}
