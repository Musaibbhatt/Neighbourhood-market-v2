document.addEventListener('DOMContentLoaded', async () => {
    const urlParams = new URLSearchParams(window.location.search);
    const recipeId = urlParams.get('id');

    if (recipeId) {
        await loadRecipeDetails(recipeId);
    } else {
        window.location.href = 'recipes.html';
    }
});

async function loadRecipeDetails(id) {
    try {
        const container = document.getElementById('recipe-detail-container');
        if (!container) return;

        // Phase 16: Skeleton Loader
        renderSkeleton(container, 1, 'recipe');

        const recipe = await apiFetch(`/recipes/${id}`);

        // SEO: Update Title
        document.title = `${recipe.title} - Recipe | Neighbourhood Market`;

        container.innerHTML = `
            <div class="grid grid-cols-2" style="gap: 40px; align-items: start;">
                <div>
                    <img src="${recipe.imageURL || 'images/recipe_placeholder.svg'}" alt="${recipe.title}" style="width: 100%; border-radius: var(--radius-lg); box-shadow: var(--shadow-md);">
                </div>
                <div>
                    <h1 style="margin-bottom: 20px;">${recipe.title}</h1>
                    <div style="display: flex; gap: 20px; margin-bottom: 30px; font-weight: 500;">
                        <span>⏱ ${recipe.prepTime}</span>
                        <span>🍽 ${recipe.servings} Servings</span>
                    </div>
                    <p style="font-size: 1.1rem; line-height: 1.8; margin-bottom: 30px;">${recipe.description}</p>
                    
                    <div class="card" style="padding: 25px; background: rgba(44, 94, 59, 0.05);">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                            <div>
                                <h3 style="margin-bottom: 5px;">Ingredients</h3>
                                <div id="recipe-total-price" class="recipe-price-tag">Calculating...</div>
                            </div>
                            <button id="add-all-ingredients" class="btn btn-primary">Add All to Cart</button>
                        </div>
                        <ul id="ingredient-list" style="display: flex; flex-direction: column; gap: 12px;">
                            ${recipe.ingredients.map(ing => {
            const p = ing.productId;
            const isOutOfStock = p && p.stock <= 0;
            return `
                                    <li style="display: flex; justify-content: space-between; align-items: center; padding-bottom: 8px; border-bottom: 1px dashed var(--border);">
                                        <div style="display: flex; flex-direction: column;">
                                            <span><strong>${ing.amount}</strong> ${ing.name}</span>
                                            ${p ? `
                                                <span style="font-size: 0.75rem; color: ${isOutOfStock ? 'var(--error)' : 'var(--success)'}; font-weight: 600;">
                                                    ${isOutOfStock ? '✖ Out of Stock' : `✔ In Stock • ${formatCurrency(p.salePrice && p.saleExpiresAt && new Date(p.saleExpiresAt) > new Date() ? p.salePrice : p.basePrice)}`}
                                                </span>
                                            ` : ''}
                                        </div>
                                        ${p ? `
                                            <button class="btn btn-outline btn-sm add-single-ing" 
                                                data-product-id="${p._id}" 
                                                data-name="${p.name}" 
                                                data-price="${(p.salePrice && p.saleExpiresAt && new Date(p.saleExpiresAt) > new Date()) ? p.salePrice : p.basePrice}" 
                                                data-img="${p.imageURL || 'images/product_placeholder.svg'}" 
                                                style="padding: 5px 12px; font-size: 0.8rem;">Add</button>
                                        ` : '<span class="text-muted" style="font-size: 0.8rem;">Manual Item</span>'}
                                    </li>
                                `;
        }).join('')}
                        </ul>
                    </div>
                </div>
            </div>

            <div style="margin-top: 60px;">
                <h2 style="margin-bottom: 30px;">Instructions</h2>
                <div style="display: flex; flex-direction: column; gap: 20px;">
                    ${recipe.instructions.map((step, index) => `
                        <div style="display: flex; gap: 20px;">
                            <span style="flex-shrink: 0; width: 35px; height: 35px; background: var(--primary); color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 700;">${index + 1}</span>
                            <p style="font-size: 1.05rem; line-height: 1.7;">${step}</p>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;

        calculateRecipeTotal(recipe);
        setupAddIngredientListeners(recipe);

    } catch (e) {
        console.error('Failed to load recipe details', e);
        const container = document.getElementById('recipe-detail-container');
        if (container) container.innerHTML = '<p class="text-error text-center">Failed to load recipe details.</p>';
    }
}

function calculateRecipeTotal(recipe) {
    const totalEl = document.getElementById('recipe-total-price');
    if (!totalEl) return;

    const now = new Date();
    const total = recipe.ingredients.reduce((sum, ing) => {
        if (!ing.productId) return sum;
        const p = ing.productId;
        const price = (p.salePrice && p.saleExpiresAt && new Date(p.saleExpiresAt) > now) ? p.salePrice : p.basePrice;
        return sum + price;
    }, 0);

    totalEl.textContent = `Est. Total: ${formatCurrency(total)}`;
}

function setupAddIngredientListeners(recipe) {
    const addAllBtn = document.getElementById('add-all-ingredients');
    if (addAllBtn) {
        addAllBtn.addEventListener('click', () => {
            const ingredientsWithProducts = recipe.ingredients.filter(ing => ing.productId);

            if (ingredientsWithProducts.length === 0) {
                alert('No linked products found for this recipe.');
                return;
            }

            addAllBtn.innerHTML = 'Adding...';
            addAllBtn.disabled = true;

            ingredientsWithProducts.forEach(ing => {
                const p = ing.productId;
                if (p.stock > 0) {
                    const now = new Date();
                    const price = (p.salePrice && p.saleExpiresAt && new Date(p.saleExpiresAt) > now) ? p.salePrice : p.basePrice;
                    addToCart({
                        id: p._id,
                        name: p.name,
                        price: price,
                        image: p.imageURL || 'images/product_placeholder.svg',
                        quantity: 1
                    });
                }
            });

            addAllBtn.innerHTML = 'Added All!';
            addAllBtn.classList.replace('btn-primary', 'btn-secondary');
            updateCartIcon();
            playSound('success');

            setTimeout(() => {
                addAllBtn.innerHTML = 'Add All to Cart';
                addAllBtn.classList.replace('btn-secondary', 'btn-primary');
                addAllBtn.disabled = false;
            }, 2000);
        });
    }

    // Single add listeners
    document.querySelectorAll('.add-single-ing').forEach(btn => {
        btn.addEventListener('click', () => {
            addToCart({
                id: btn.dataset.productId,
                name: btn.dataset.name,
                price: parseFloat(btn.dataset.price),
                image: btn.dataset.img,
                quantity: 1
            });
            btn.innerHTML = '✓';
            btn.classList.replace('btn-outline', 'btn-secondary');
            updateCartIcon();
            playSound('cart-add');
        });
    });
}

function addToCart(item) {
    const cart = getCart();
    const existingIndex = cart.findIndex(cartItem => cartItem.id === item.id);
    if (existingIndex >= 0) {
        cart[existingIndex].quantity += 1;
    } else {
        cart.push(item);
    }
    saveCart(cart);
}
