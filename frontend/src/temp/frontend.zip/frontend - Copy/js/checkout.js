let currentTip = 0;
let isDelivery = true;
let appliedCoupon = null;

document.addEventListener('DOMContentLoaded', () => {
    // Phase 7: Enforce Login
    const token = localStorage.getItem('userToken');
    if (!token) {
        window.location.href = 'login.html?redirect=checkout.html';
        return;
    }

    // Auto-fill from localStorage if available
    const userData = JSON.parse(localStorage.getItem('userData') || '{}');
    if (userData.name) document.getElementById('name').value = userData.name;
    if (userData.mobile) document.getElementById('phone').value = userData.mobile;
    // Manual address is handled after addresses are loaded

    loadSavedAddresses();

    populateCheckoutSummary();
    setupCheckoutForm();
    setupCheckoutUI();
    setupCouponLogic();
});

function populateCheckoutSummary() {
    const summaryContainer = document.getElementById('checkout-items');
    const subtotalEl = document.getElementById('checkout-subtotal');
    const discountRow = document.getElementById('discount-row');
    const discountCodeName = document.getElementById('discount-code-name');
    const discountAmtEl = document.getElementById('checkout-discount');
    const deliveryEl = document.getElementById('checkout-delivery-fee');
    const tipEl = document.getElementById('checkout-tip');
    const finalTotalEl = document.getElementById('checkout-final-total');

    if (!summaryContainer) return;

    const cart = getCart();
    if (cart.length === 0) {
        window.location.href = 'cart.html';
        return;
    }

    summaryContainer.innerHTML = '';
    let subtotal = 0;

    cart.forEach(item => {
        const itemTotal = item.price * item.quantity;
        subtotal += itemTotal;

        const row = document.createElement('div');
        row.style.display = 'flex';
        row.style.justifyContent = 'space-between';
        row.style.marginBottom = '10px';
        row.style.fontSize = '0.9rem';
        row.innerHTML = `
            <span style="color: rgba(255,255,255,0.8);">${item.name} x ${item.quantity}</span>
            <span style="font-weight: 500;">${formatCurrency(itemTotal)}</span>
        `;
        summaryContainer.appendChild(row);
    });

    const deliveryFee = isDelivery ? parseFloat(localStorage.getItem('deliveryFee') || '0') : 0;

    let discount = 0;
    if (appliedCoupon) {
        discount = appliedCoupon.calculatedDiscount;
        discountRow.classList.remove('d-none');
        discountCodeName.textContent = appliedCoupon.code;
        discountAmtEl.textContent = `-${formatCurrency(discount)}`;
        // If display:flex was overridden by d-none, ensure it's visible correctly
        discountRow.style.display = 'flex';
    } else {
        discountRow.classList.add('d-none');
        discountRow.style.display = 'none';
    }

    const finalTotal = subtotal + deliveryFee + currentTip - discount;

    if (subtotalEl) subtotalEl.textContent = formatCurrency(subtotal);
    if (deliveryEl) deliveryEl.textContent = deliveryFee > 0 ? formatCurrency(deliveryFee) : 'Free';
    if (tipEl) tipEl.textContent = formatCurrency(currentTip);
    if (finalTotalEl) finalTotalEl.textContent = formatCurrency(finalTotal);

    // Store for final submission
    localStorage.setItem('finalOrderTotal', finalTotal.toString());
}

function setupCouponLogic() {
    const applyBtn = document.getElementById('apply-coupon-btn');
    const couponInput = document.getElementById('coupon-code');
    const messageEl = document.getElementById('coupon-message');

    if (!applyBtn) return;

    applyBtn.addEventListener('click', async () => {
        const code = couponInput.value.trim();
        if (!code) return;

        try {
            messageEl.textContent = 'Validating...';
            messageEl.style.color = 'white';

            const cart = getCart();
            const subtotal = cart.reduce((acc, item) => acc + (item.price * item.quantity), 0);

            const result = await apiFetch(`/coupons/validate?code=${code}&subtotal=${subtotal}`);

            appliedCoupon = result;
            messageEl.textContent = 'Coupon applied successfully!';
            messageEl.style.color = '#81c784';
            populateCheckoutSummary();
        } catch (error) {
            appliedCoupon = null;
            messageEl.textContent = error.message;
            messageEl.style.color = '#e57373';
            populateCheckoutSummary();
        }
    });
}

function setupCheckoutUI() {
    // Delivery / Pickup Toggle
    const btnDelivery = document.getElementById('btn-delivery');
    const btnPickup = document.getElementById('btn-pickup');
    const deliverySection = document.getElementById('delivery-info-section');
    const addressInput = document.getElementById('address');

    btnDelivery.addEventListener('click', () => {
        isDelivery = true;
        btnDelivery.classList.add('btn-primary');
        btnPickup.classList.remove('btn-primary');
        deliverySection.classList.remove('d-none');
        addressInput.required = true;
        populateCheckoutSummary();
    });

    btnPickup.addEventListener('click', () => {
        isDelivery = false;
        btnPickup.classList.add('btn-primary');
        btnDelivery.classList.remove('btn-primary');
        deliverySection.classList.add('d-none');
        addressInput.required = false;
        populateCheckoutSummary();
    });

    // Tipping Logic
    const tipBtns = document.querySelectorAll('.tip-btn');
    const customTipBtn = document.getElementById('custom-tip-btn');
    const customTipContainer = document.getElementById('custom-tip-container');
    const customTipInput = document.getElementById('custom-tip-input');

    tipBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            tipBtns.forEach(b => b.classList.replace('btn-primary', 'btn-outline'));
            btn.classList.replace('btn-outline', 'btn-primary');
            customTipContainer.classList.add('d-none');

            currentTip = parseInt(btn.dataset.tip);
            populateCheckoutSummary();
        });
    });

    customTipBtn.addEventListener('click', () => {
        tipBtns.forEach(b => b.classList.replace('btn-primary', 'btn-outline'));
        customTipBtn.classList.replace('btn-outline', 'btn-primary');
        customTipContainer.classList.remove('d-none');
        customTipInput.focus();
    });

    customTipInput.addEventListener('input', (e) => {
        currentTip = parseFloat(e.target.value) || 0;
        populateCheckoutSummary();
    });
}

function setupCheckoutForm() {
    const form = document.getElementById('checkout-form');
    if (!form) return;

    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const submitBtn = form.querySelector('button[type="submit"]');
        submitBtn.disabled = true;
        submitBtn.textContent = 'Processing...';

        const cart = getCart();
        const subtotal = cart.reduce((acc, item) => acc + (item.price * item.quantity), 0);
        const deliveryFee = isDelivery ? parseFloat(localStorage.getItem('deliveryFee') || '0') : 0;
        const total = subtotal + deliveryFee + currentTip;

        const addressEl = document.querySelector('input[name="saved-address"]:checked');
        let selectedAddress = '';

        if (isDelivery) {
            if (addressEl) {
                selectedAddress = addressEl.value;
            } else {
                selectedAddress = document.getElementById('address').value;
            }
        } else {
            selectedAddress = 'PICKUP AT STORE';
        }

        const orderData = {
            customerName: document.getElementById('name').value,
            phone: document.getElementById('phone').value,
            address: selectedAddress,
            orderType: isDelivery ? 'Delivery' : 'Pickup',
            products: cart.map(item => ({
                product: item.id,
                name: item.name,
                price: item.price,
                quantity: item.quantity
            })),
            subtotal: subtotal,
            deliveryFee: deliveryFee,
            tip: currentTip,
            discountAmount: appliedCoupon ? appliedCoupon.calculatedDiscount : 0,
            couponCode: appliedCoupon ? appliedCoupon.code : null,
            totalPrice: total,
            notes: document.getElementById('order-notes').value, // Added notes
            paymentMethod: 'Pay on Delivery'
        };

        try {
            const result = await apiFetch('/orders', {
                method: 'POST',
                body: orderData
            });

            clearCart();
            window.location.href = `order-confirmation.html?orderId=${result._id}`;
        } catch (error) {
            alert('Failed to place order. Please try again.');
            submitBtn.disabled = false;
            submitBtn.textContent = 'Place Order';
        }
    });
}

async function loadSavedAddresses() {
    const container = document.getElementById('saved-addresses-container');
    const optionsGrid = document.getElementById('address-options');
    const manualContainer = document.getElementById('manual-address-container');
    const manageLink = document.getElementById('manage-addresses-link');
    const addressInput = document.getElementById('address');

    try {
        const user = await apiFetch('/users/profile', {
            headers: { 'Authorization': `Bearer ${localStorage.getItem('userToken')}` }
        });

        const addresses = user.addresses || [];
        if (addresses.length > 0) {
            container.classList.remove('d-none');
            manageLink.classList.remove('d-none');
            // Make manual address optional if a saved one is chosen
            addressInput.required = false;

            optionsGrid.innerHTML = addresses.map(addr => `
                <label class="address-select-card" style="border: 1px solid var(--border); padding: 15px; border-radius: 8px; cursor: pointer; display: flex; align-items: flex-start; gap: 10px; margin-bottom: 10px;">
                    <input type="radio" name="saved-address" value="${addr.street}, ${addr.city}, ${addr.zip}" ${addr.isDefault === 'true' ? 'checked' : ''} style="margin-top: 4px;">
                    <div style="flex: 1;">
                        <div style="display: flex; justify-content: space-between;">
                            <span style="font-weight: 700; font-size: 0.8rem; text-transform: uppercase; color: var(--text-muted);">${addr.label}</span>
                            ${addr.isDefault === 'true' ? '<span style="font-size: 0.7rem; color: var(--primary); font-weight: 800;">DEFAULT</span>' : ''}
                        </div>
                        <div style="font-size: 0.9rem;">${addr.street}, ${addr.city}, ${addr.zip}</div>
                    </div>
                </label>
            `).join('') + `
                <label class="address-select-card" style="border: 1px solid var(--border); padding: 15px; border-radius: 8px; cursor: pointer; display: flex; align-items: flex-start; gap: 10px;">
                    <input type="radio" name="saved-address" value="manual" id="radio-manual-address" style="margin-top: 4px;">
                    <div style="flex: 1;">
                        <div style="font-weight: 700; font-size: 0.8rem; text-transform: uppercase; color: var(--text-muted);">OTHER</div>
                        <div style="font-size: 0.9rem;">Use a different address</div>
                    </div>
                </label>
            `;

            // Radio button change listener
            document.querySelectorAll('input[name="saved-address"]').forEach(radio => {
                radio.addEventListener('change', (e) => {
                    if (e.target.value === 'manual') {
                        manualContainer.classList.remove('d-none');
                        addressInput.required = true;
                        addressInput.focus();
                    } else {
                        manualContainer.classList.add('d-none');
                        addressInput.required = false;
                    }
                });
            });

            // Initial state based on if default is checked
            const manualRadio = document.getElementById('radio-manual-address');
            if (manualRadio && !manualRadio.checked) {
                manualContainer.classList.add('d-none');
            }
        } else {
            if (user.address) addressInput.value = user.address;
        }
    } catch (err) {
        console.error('Failed to load addresses:', err);
    }
}
