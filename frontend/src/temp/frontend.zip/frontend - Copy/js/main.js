// Define the base URL for the backend API
const API_BASE_URL = 'http://localhost:5000/api';

/**
 * Helper to get the JWT token from localStorage
 * Prefer admin token when present so admin APIs work reliably.
 */
function getToken() {
    return localStorage.getItem('adminToken') || localStorage.getItem('userToken');
}

/**
 * Generic fetch wrapper for API calls
 * @param {string} endpoint - The API endpoint starting with / (e.g., /products)
 * @param {object} options - Fetch options (method, body, etc.)
 */
async function apiFetch(endpoint, options = {}) {
    const url = `${API_BASE_URL}${endpoint}`;

    // Set default headers
    const headers = {
        'Content-Type': 'application/json',
        ...options.headers
    };

    // Add authorization token if available
    const token = getToken();
    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }

    const config = {
        ...options,
        headers
    };

    // Stringify body if it's an object and not FormData
    if (config.body && typeof config.body === 'object' && !(config.body instanceof FormData)) {
        config.body = JSON.stringify(config.body);
    }

    try {
        const response = await fetch(url, config);
        const data = await response.json().catch(() => ({})); // Handle empty responses gently

        if (!response.ok) {
            const msg = data.message || `HTTP Error: ${response.status}`;
            // Show toast for server-side rate limit
            if (response.status === 429) showToast('Too many requests. Please slow down!', 'warning');
            throw new Error(msg);
        }

        return data;
    } catch (error) {
        if (error.message === 'Failed to fetch') {
            showToast('Network error — check your connection.', 'error');
        }
        console.error('API Error:', error);
        throw error;
    }
}

// =============================================================
// Phase 19: Global Toast Notification System
// =============================================================

/**
 * Show a toast notification
 * @param {string} message - Text to display
 * @param {'success'|'error'|'warning'|'info'} type - Visual type
 * @param {number} duration - Auto-dismiss time in ms (default 3500)
 */
function showToast(message, type = 'info', duration = 3500) {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;

    const icons = { success: '✅', error: '❌', warning: '⚠️', info: 'ℹ️' };
    toast.innerHTML = `<span class="toast-icon">${icons[type] || 'ℹ️'}</span><span>${message}</span><button class="toast-close">✕</button>`;

    container.appendChild(toast);

    // Trigger animation
    requestAnimationFrame(() => toast.classList.add('toast-show'));

    const dismiss = () => {
        toast.classList.remove('toast-show');
        setTimeout(() => toast.remove(), 300);
    };

    toast.querySelector('.toast-close').addEventListener('click', dismiss);
    setTimeout(dismiss, duration);
}

// Make globally accessible
window.showToast = showToast;

/**
 * Offline / Online Network Detection
 */
function initOfflineDetector() {
    let offlineToast = null;

    const onOffline = () => {
        if (!offlineToast) {
            let container = document.getElementById('toast-container');
            if (!container) {
                container = document.createElement('div');
                container.id = 'toast-container';
                document.body.appendChild(container);
            }
            offlineToast = document.createElement('div');
            offlineToast.className = 'toast toast-error toast-persistent toast-show';
            offlineToast.innerHTML = `<span class="toast-icon">📡</span><span>You are offline. Check your connection.</span>`;
            container.appendChild(offlineToast);
        }
    };

    const onOnline = () => {
        if (offlineToast) {
            offlineToast.classList.remove('toast-show');
            setTimeout(() => { offlineToast?.remove(); offlineToast = null; }, 300);
        }
        showToast('Back online! 🎉', 'success');
    };

    window.addEventListener('offline', onOffline);
    window.addEventListener('online', onOnline);
    if (!navigator.onLine) onOffline();
}

// -------------------------------------------------------------
// Global UI Functions
// -------------------------------------------------------------

/**
 * Mobile navigation toggle
 */
function initMobileMenu() {
    const menuBtn = document.querySelector('.mobile-menu-btn');
    const navLinks = document.querySelector('.nav-links');

    if (menuBtn && navLinks) {
        menuBtn.addEventListener('click', () => {
            navLinks.classList.toggle('show');
        });
    }
}

/**
 * Cart state management and icon updates
 */
function getCart() {
    const cart = localStorage.getItem('shoppingCart');
    return cart ? JSON.parse(cart) : [];
}

function saveCart(cart) {
    localStorage.setItem('shoppingCart', JSON.stringify(cart));
    updateCartIcon();
}

function clearCart() {
    localStorage.removeItem('shoppingCart');
    updateCartIcon();
}

function updateCartIcon() {
    const cartCountEl = document.querySelector('.cart-count');
    if (cartCountEl) {
        const cart = getCart();
        const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
        cartCountEl.textContent = totalItems;

        // Hide if empty, show if has items
        if (totalItems > 0) {
            cartCountEl.classList.remove('d-none');
        } else {
            cartCountEl.classList.add('d-none');
        }
    }
}

/**
 * Helper to format currency
 */
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD'
    }).format(amount);
}

/**
 * Initialize Global Search
 */
function initSearchBar() {
    const searchInput = document.getElementById('global-search-input');
    const searchBtn = document.getElementById('global-search-btn');
    const searchWrapper = document.querySelector('.global-search');

    // Create results dropdown
    const searchResults = document.createElement('div');
    searchResults.id = 'search-autocomplete-results';
    searchResults.className = 'autocomplete-dropdown d-none';

    if (searchWrapper && searchInput) {
        searchWrapper.style.position = 'relative';
        searchWrapper.appendChild(searchResults);

        const handleSearch = () => {
            const query = searchInput.value.trim();
            if (query) {
                window.location.href = `shop.html?search=${encodeURIComponent(query)}`;
            }
        };

        searchBtn.addEventListener('click', handleSearch);
        searchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') handleSearch();
        });

        searchInput.addEventListener('input', debounce(async (e) => {
            const query = e.target.value.trim();
            if (query.length < 2) {
                searchResults.classList.add('d-none');
                return;
            }

            try {
                const products = await apiFetch(`/products?search=${encodeURIComponent(query)}&limit=5`);
                if (products.length > 0) {
                    searchResults.innerHTML = products.map(p => `
                        <div class="autocomplete-item" onclick="window.location.href='shop.html?search=${encodeURIComponent(p.name)}'">
                            <img src="${p.imageURL || 'images/product_placeholder.svg'}" width="30" height="30" style="object-fit: contain;">
                            <div style="flex: 1;">
                                <div style="font-weight: 600; font-size: 0.9rem;">${p.name}</div>
                                <div style="font-size: 0.75rem; color: var(--text-muted);">${p.brand || ''} • ${formatCurrency(p.basePrice)}</div>
                            </div>
                        </div>
                    `).join('') + `
                        <div class="autocomplete-footer" onclick="window.location.href='shop.html?search=${encodeURIComponent(query)}'">
                            See all results for "${query}"
                        </div>
                    `;
                    searchResults.classList.remove('d-none');
                } else {
                    searchResults.classList.add('d-none');
                }
            } catch (err) {
                console.error('Autocomplete error:', err);
            }
        }, 300));

        // Hide dropdown on click outside
        document.addEventListener('click', (e) => {
            if (!searchWrapper.contains(e.target)) {
                searchResults.classList.add('d-none');
            }
        });
    }
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

/**
 * Initialize Location/ZIP Selector
 */
function initLocationSelector() {
    const locationBtn = document.getElementById('location-selector');
    const locationText = document.getElementById('current-location');

    // Load saved location
    const savedZip = localStorage.getItem('userZip');
    if (savedZip) {
        locationText.textContent = savedZip;
    }

    if (locationBtn) {
        locationBtn.addEventListener('click', () => {
            const zip = prompt('Enter your ZIP code to check delivery availability:', savedZip || '');
            if (zip !== null) {
                const cleanZip = zip.trim();
                if (cleanZip) {
                    localStorage.setItem('userZip', cleanZip);
                    locationText.textContent = cleanZip;
                    // Trigger a custom event or reload if on a page that needs it
                    window.dispatchEvent(new CustomEvent('locationChanged', { detail: { zip: cleanZip } }));
                    location.reload(); // Simplest way to refresh inventory/fees
                }
            }
        });
    }
}

/**
 * Initialize Header Auth Links
 */
function initHeaderAuth() {
    const navLinks = document.querySelector('.nav-links');
    if (!navLinks) return;

    const token = localStorage.getItem('userToken');
    const loginLink = document.createElement('a');
    loginLink.className = 'nav-link';

    if (token) {
        loginLink.href = 'profile.html';
        loginLink.textContent = 'Account';
        loginLink.id = 'nav-account';
    } else {
        loginLink.href = 'login.html';
        loginLink.textContent = 'Login';
        loginLink.id = 'nav-login';
    }

    // Avoid duplicates if script runs twice
    if (!document.getElementById('nav-account') && !document.getElementById('nav-login')) {
        navLinks.appendChild(loginLink);
    }
}

// Newsletter feature removed

/**
 * Global Audio Manager for UI sounds
 */
function playSound(type) {
    const sounds = {
        'cart-add': 'https://assets.mixkit.co/active_storage/sfx/2568/2568-preview.mp3', // Subtle "pop"
        'success': 'https://assets.mixkit.co/active_storage/sfx/1435/1435-preview.mp3'   // "Chime"
    };

    if (sounds[type]) {
        const audio = new Audio(sounds[type]);
        audio.volume = 0.3;
        audio.play().catch(err => console.log('Audio play failed:', err));
    }
}

/**
 * Render Skeletons for loading states
 */
function renderSkeleton(container, count = 4, type = 'product') {
    if (!container) return;
    container.innerHTML = '';

    for (let i = 0; i < count; i++) {
        const skeleton = document.createElement('div');
        skeleton.className = type === 'product' ? 'card product-card' : 'card';
        skeleton.style.padding = '15px';

        if (type === 'product') {
            skeleton.innerHTML = `
                <div class="skeleton skeleton-img"></div>
                <div class="skeleton skeleton-title"></div>
                <div class="skeleton skeleton-text"></div>
                <div class="skeleton skeleton-text" style="width: 50%;"></div>
                <div class="skeleton" style="height: 40px; border-radius: 20px; margin-top: 15px;"></div>
            `;
        } else {
            skeleton.innerHTML = `
                <div class="skeleton skeleton-img" style="height: 150px;"></div>
                <div class="skeleton skeleton-title"></div>
                <div class="skeleton skeleton-text"></div>
            `;
        }
        container.appendChild(skeleton);
    }
}

/**
 * Cookie Consent Banner
 */
function initCookieConsent() {
    if (localStorage.getItem('cookie-accepted')) return;

    const banner = document.createElement('div');
    banner.className = 'cookie-banner';
    banner.innerHTML = `
        <div class="container" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
            <p style="margin: 0; font-size: 0.9rem;">We use cookies to ensure you get the best experience on our website. <a href="privacy.html" style="color: var(--secondary); text-decoration: underline;">Learn more</a></p>
            <button class="btn btn-secondary btn-sm" id="accept-cookies" style="padding: 8px 20px; font-size: 0.85rem;">Accept All</button>
        </div>
    `;
    document.body.appendChild(banner);

    document.getElementById('accept-cookies').addEventListener('click', () => {
        localStorage.setItem('cookie-accepted', 'true');
        banner.style.transform = 'translateY(100%)';
        setTimeout(() => banner.remove(), 300);
    });
}

/**
 * Back to Top Button
 */
function initBackToTop() {
    const btn = document.createElement('button');
    btn.className = 'back-to-top';
    btn.innerHTML = `
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="18 15 12 9 6 15"></polyline>
        </svg>
    `;
    document.body.appendChild(btn);

    window.addEventListener('scroll', () => {
        if (window.scrollY > 500) {
            btn.classList.add('show');
        } else {
            btn.classList.remove('show');
        }
    });

    btn.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
}

/**
 * Phase 19: Reusable form validation utility
 * Highlights invalid fields with a red border and helper message.
 * @param {HTMLFormElement} formEl
 * @returns {boolean} true if valid
 */
function validateForm(formEl) {
    if (!formEl) return true;
    let isValid = true;

    // Remove previous validation state
    formEl.querySelectorAll('.field-error').forEach(el => el.remove());
    formEl.querySelectorAll('.input-error').forEach(el => el.classList.remove('input-error'));

    formEl.querySelectorAll('[required]').forEach(input => {
        const value = input.value.trim();
        let error = '';

        if (!value) {
            error = `${input.placeholder || input.name || 'This field'} is required.`;
        } else if (input.type === 'email' && !/^[^@]+@[^@]+\.[^@]+$/.test(value)) {
            error = 'Please enter a valid email address.';
        } else if (input.type === 'tel' && !/^[0-9+\-\s]{7,15}$/.test(value)) {
            error = 'Please enter a valid phone number.';
        }

        if (error) {
            isValid = false;
            input.classList.add('input-error');
            const msg = document.createElement('small');
            msg.className = 'field-error';
            msg.textContent = error;
            input.parentNode.insertBefore(msg, input.nextSibling);
        }
    });

    if (!isValid) showToast('Please fix the highlighted fields.', 'warning');
    return isValid;
}

window.validateForm = validateForm;

// Initialize global scripts on load
document.addEventListener('DOMContentLoaded', () => {
    initMobileMenu();
    updateCartIcon();
    initSearchBar();
    initLocationSelector();
    initHeaderAuth();
    // initNewsletter(); // removed
    initCookieConsent();
    initBackToTop();
    initOfflineDetector();

    // Apply fade-in animation to main content
    const mainContent = document.querySelector('main');
    if (mainContent) mainContent.classList.add('page-fade-in');

    // Global year update
    const yearEl = document.getElementById('year');
    if (yearEl) yearEl.textContent = new Date().getFullYear();

    // Phase 20: Social Proof Ticker (only on homepage)
    if (document.getElementById('social-proof-ticker')) {
        initSocialProofTicker();
    }
});

// =============================================================
// Phase 20: Service Worker Registration
// =============================================================
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker
            .register('/sw.js')
            .then(() => console.log('[SW] Registered successfully'))
            .catch((err) => console.warn('[SW] Registration failed:', err));
    });
}

// =============================================================
// Phase 20: Social Proof Ticker
// =============================================================
function initSocialProofTicker() {
    const names = ['Ahmed', 'Sara', 'John', 'Priya', 'Omar', 'Emma', 'Liam', 'Fatima', 'Carlos', 'Yuki'];
    const products = [
        'Organic Apples 🍎', 'Fresh Milk 🥛', 'Sourdough Bread 🍞',
        'Greek Yogurt', 'Avocados 🥑', 'Chicken Breast 🍗',
        'Orange Juice 🍊', 'Baby Spinach 🌿', 'Almond Butter', 'Cheddar Cheese 🧀'
    ];
    const timeAgo = ['just now', '2 min ago', '5 min ago', '8 min ago', '12 min ago'];

    const ticker = document.getElementById('social-proof-ticker');
    if (!ticker) return;

    let index = 0;

    function showNext() {
        const name = names[Math.floor(Math.random() * names.length)];
        const product = products[Math.floor(Math.random() * products.length)];
        const time = timeAgo[Math.floor(Math.random() * timeAgo.length)];

        ticker.style.opacity = '0';
        ticker.style.transform = 'translateY(8px)';

        setTimeout(() => {
            ticker.innerHTML = `🛒 <strong>${name}</strong> purchased <strong>${product}</strong> · <span style="color:var(--text-muted); font-size:0.85em">${time}</span>`;
            ticker.style.opacity = '1';
            ticker.style.transform = 'translateY(0)';
        }, 300);
    }

    showNext();
    setInterval(showNext, 4000);
}
