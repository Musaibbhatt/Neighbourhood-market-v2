document.addEventListener('DOMContentLoaded', async () => {
    await loadRecipes();
});

async function loadRecipes() {
    try {
        const recipes = await apiFetch('/recipes');
        const grid = document.getElementById('recipe-grid');
        if (!grid) return;

        if (recipes.length === 0) {
            grid.innerHTML = '<p class="text-center" style="grid-column: 1/-1;">No recipes found yet.</p>';
            return;
        }

        grid.innerHTML = '';
        recipes.forEach(recipe => {
            const card = document.createElement('div');
            card.className = 'card';
            card.innerHTML = `
                <img src="${recipe.imageURL || 'images/recipe_placeholder.svg'}" alt="${recipe.title}" style="height: 200px; width: 100%; object-fit: cover;">
                <div style="padding: 20px;">
                    <h3>${recipe.title}</h3>
                    <p class="text-muted" style="font-size: 0.9rem; margin-bottom: 15px;">${recipe.description.substring(0, 100)}...</p>
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <span class="text-muted" style="font-size: 0.85rem;">${recipe.prepTime} • ${recipe.servings} Servings</span>
                        <a href="recipe-details.html?id=${recipe._id}" class="btn btn-outline">View Recipe</a>
                    </div>
                </div>
            `;
            grid.appendChild(card);
        });
    } catch (e) {
        console.error('Failed to load recipes', e);
        const grid = document.getElementById('recipe-grid');
        if (grid) grid.innerHTML = '<p class="text-error text-center" style="grid-column: 1/-1;">Failed to load recipes.</p>';
    }
}
