document.addEventListener('DOMContentLoaded', async () => {
    const token = localStorage.getItem('userToken');
    if (!token) {
        window.location.href = 'login.html?redirect=profile.html';
        return;
    }

    // Tab Switching
    const navProfile = document.getElementById('nav-profile');
    const navAddresses = document.getElementById('nav-addresses');
    const navWishlist = document.getElementById('nav-wishlist');
    const navOrders = document.getElementById('nav-orders');
    const navRecentlyViewed = document.getElementById('nav-recently-viewed');

    const sectionProfile = document.getElementById('section-profile');
    const sectionAddresses = document.getElementById('section-addresses');
    const sectionWishlist = document.getElementById('section-wishlist');
    const sectionOrders = document.getElementById('section-orders');
    const sectionRecentlyViewed = document.getElementById('section-recently-viewed');

    function hideAll() {
        [sectionProfile, sectionAddresses, sectionWishlist, sectionRecentlyViewed, sectionOrders].forEach(s => s.classList.add('d-none'));
        [navProfile, navAddresses, navWishlist, navRecentlyViewed, navOrders].forEach(n => n.classList.remove('active'));
    }

    navProfile.addEventListener('click', () => {
        hideAll();
        navProfile.classList.add('active');
        sectionProfile.classList.remove('d-none');
    });

    navAddresses.addEventListener('click', () => {
        hideAll();
        navAddresses.classList.add('active');
        sectionAddresses.classList.remove('d-none');
        loadAddresses();
    });

    navWishlist.addEventListener('click', () => {
        hideAll();
        navWishlist.classList.add('active');
        sectionWishlist.classList.remove('d-none');
        loadWishlist();
    });

    navOrders.addEventListener('click', () => {
        hideAll();
        navOrders.classList.add('active');
        sectionOrders.classList.remove('d-none');
        loadOrders();
    });

    navRecentlyViewed.addEventListener('click', () => {
        hideAll();
        navRecentlyViewed.classList.add('active');
        sectionRecentlyViewed.classList.remove('d-none');
        loadRecentlyViewed();
    });

    // Load Profile
    await loadProfile();

    // Logout
    document.getElementById('logout-btn').onclick = () => {
        localStorage.removeItem('userToken');
        localStorage.removeItem('userData');
        window.location.href = 'index.html';
    };
});

async function loadProfile() {
    try {
        const user = await apiFetch('/users/profile', {
            headers: { 'Authorization': `Bearer ${localStorage.getItem('userToken')}` }
        });
        document.getElementById('profile-name').value = user.name;
        document.getElementById('profile-email').value = user.email;
        document.getElementById('profile-mobile').value = user.mobile;
        // Loyalty points UI removed

        // Referral display
        if (user.referralCode) {
            document.getElementById('referral-code-display').textContent = user.referralCode;
        }
        if (user.referredBy) {
            document.getElementById('claim-referral-section').classList.add('d-none');
            const msg = document.getElementById('claimed-by-msg');
            msg.classList.remove('d-none');
            msg.textContent = `✓ Referred by ${user.referredBy.name || 'a friend'}`;
        }
    } catch (err) {
        console.error(err);
    }
}

document.getElementById('profile-form').onsubmit = async (e) => {
    e.preventDefault();
    const btn = document.getElementById('save-profile-btn');
    const name = document.getElementById('profile-name').value;
    const mobile = document.getElementById('profile-mobile').value;
    const address = document.getElementById('profile-address').value;

    try {
        btn.disabled = true;
        btn.textContent = 'Saving...';
        await apiFetch('/users/profile', {
            method: 'PUT',
            headers: { 'Authorization': `Bearer ${localStorage.getItem('userToken')}` },
            body: { name, mobile }
        });
        alert('Profile updated successfully!');
    } catch (err) {
        alert('Failed to update profile: ' + err.message);
    } finally {
        btn.disabled = false;
        btn.textContent = 'Save Changes';
    }
};

async function loadOrders() {
    const container = document.getElementById('orders-container');
    try {
        const orders = await apiFetch('/orders/my-orders', {
            headers: { 'Authorization': `Bearer ${localStorage.getItem('userToken')}` }
        });

        if (orders.length === 0) {
            container.innerHTML = '<p class="text-muted">You haven\'t placed any orders yet.</p>';
            return;
        }

        container.innerHTML = orders.map(order => `
            <div class="order-card">
                <div class="order-header">
                    <div>
                        <h4 style="margin: 0;">Order #${order._id.slice(-6).toUpperCase()}</h4>
                        <p class="text-muted" style="font-size: 0.85rem;">Placed on ${new Date(order.createdAt).toLocaleDateString()}</p>
                    </div>
                    <div style="text-align: right;">
                        <span class="badge ${getStatusBadgeClass(order.orderStatus)}">${order.orderStatus}</span>
                        <div style="font-weight: 700; margin-top: 5px; color: var(--primary);">${formatCurrency(order.totalPrice)}</div>
                    </div>
                </div>
                <div style="margin-bottom: 15px; font-size: 0.9rem;">
                    ${order.products.map(p => `${p.name} x ${p.quantity}`).join(', ')}
                </div>
                <div style="display: flex; gap: 10px;">
                    <button class="btn btn-sm btn-primary" onclick="reorder('${order._id}')">Reorder Items</button>
                    <a href="track-order.html?id=${order._id}" class="btn btn-sm btn-outline">Track Order</a>
                </div>
            </div>
        `).join('');
    } catch (err) {
        container.innerHTML = '<p class="text-error">Failed to load orders.</p>';
    }
}

function getStatusBadgeClass(status) {
    if (status === 'Delivered') return 'badge-delivered';
    if (status === 'Cancelled') return 'badge-cancelled';
    return 'badge-pending';
}

async function reorder(orderId) {
    try {
        const order = await apiFetch(`/orders/${orderId}`);
        const cart = getCart();

        order.products.forEach(item => {
            const existing = cart.find(c => c.id === item.product._id || c.id === item.product);
            if (existing) {
                existing.quantity += item.quantity;
            } else {
                cart.push({
                    id: item.product._id || item.product,
                    name: item.name,
                    price: item.price,
                    quantity: item.quantity,
                    image: item.product.imageURL || 'images/product_placeholder.svg'
                });
            }
        });

        saveCart(cart);
        alert('Items added to cart!');
        window.location.href = 'cart.html';
    } catch (err) {
        alert('Failed to reorder: ' + err.message);
    }
}

// Wishlist Logic
async function loadWishlist() {
    const grid = document.getElementById('wishlist-grid');
    try {
        const items = await apiFetch('/users/wishlist', {
            headers: { 'Authorization': `Bearer ${localStorage.getItem('userToken')}` }
        });

        if (items.length === 0) {
            grid.innerHTML = `
                <div style="grid-column: 1/-1; text-align: center; padding: 60px 0;">
                    <div style="margin-bottom: 20px; opacity: 0.1;">
                        <svg width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                            <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
                        </svg>
                    </div>
                    <h3 style="margin-bottom: 10px;">Your wishlist is empty</h3>
                    <p class="text-muted" style="margin-bottom: 25px;">Save items you love to find them easily later.</p>
                    <a href="shop.html" class="btn btn-primary" style="padding: 10px 30px;">Explore Shop</a>
                </div>
            `;
            return;
        }

        grid.innerHTML = items.map(item => `
            <div class="card" style="padding: 15px; display: flex; gap: 15px; align-items: center;">
                <img src="${item.imageURL || 'images/product_placeholder.svg'}" style="width: 80px; height: 80px; object-fit: contain;">
                <div style="flex: 1;">
                    <h4 style="margin: 0;">${item.name}</h4>
                    <div style="color: var(--primary); font-weight: 700;">${formatCurrency(item.basePrice)}</div>
                </div>
                <div style="display: flex; flex-direction: column; gap: 5px;">
                    <button class="btn btn-sm btn-primary" onclick="window.location.href='shop.html?search=${encodeURIComponent(item.name)}'">View</button>
                    <button class="btn btn-sm btn-outline" style="color: var(--error); border-color: var(--error);" onclick="removeFromWishlist('${item._id}')">Remove</button>
                </div>
            </div>
        `).join('');
    } catch (err) {
        grid.innerHTML = '<p class="text-error">Failed to load wishlist.</p>';
    }
}

async function removeFromWishlist(id) {
    if (!confirm('Remove this item from your wishlist?')) return;
    try {
        await apiFetch(`/users/wishlist/toggle/${id}`, {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${localStorage.getItem('userToken')}` }
        });
        loadWishlist();
    } catch (err) {
        alert('Failed to remove item');
    }
}

// Address Book Logic
async function loadAddresses() {
    const grid = document.getElementById('addresses-grid');
    try {
        const user = await apiFetch('/users/profile', {
            headers: { 'Authorization': `Bearer ${localStorage.getItem('userToken')}` }
        });
        const addresses = user.addresses || [];

        if (addresses.length === 0) {
            grid.innerHTML = '<p class="text-muted" style="grid-column: 1/-1;">No saved addresses yet.</p>';
            return;
        }

        grid.innerHTML = addresses.map(addr => `
            <div class="card" style="padding: 20px; border: ${addr.isDefault === 'true' ? '2px solid var(--primary)' : '1px solid var(--border)'};">
                <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                    <span style="font-weight: 700; text-transform: uppercase; font-size: 0.8rem; background: #eee; padding: 2px 8px; border-radius: 4px;">${addr.label}</span>
                    ${addr.isDefault === 'true' ? '<span style="color: var(--primary); font-size: 0.8rem; font-weight: 700;">DEFAULT</span>' : ''}
                </div>
                <div style="margin-bottom: 15px; font-size: 0.95rem;">
                    ${addr.street}<br>
                    ${addr.city}, ${addr.zip}
                </div>
                <div style="display: flex; gap: 10px;">
                    ${addr.isDefault === 'false' ? `<button class="btn btn-sm btn-outline" onclick="setDefaultAddress('${addr._id}')">Set Default</button>` : ''}
                    <button class="btn btn-sm btn-outline" style="color: var(--error); border-color: var(--error);" onclick="deleteAddress('${addr._id}')">Delete</button>
                </div>
            </div>
        `).join('');
    } catch (err) {
        grid.innerHTML = '<p class="text-error">Failed to load addresses.</p>';
    }
}

function openAddressModal() {
    document.getElementById('address-modal').classList.remove('d-none');
}

function closeAddressModal() {
    document.getElementById('address-modal').classList.add('d-none');
    document.getElementById('address-form').reset();
}

document.getElementById('address-form').onsubmit = async (e) => {
    e.preventDefault();
    const label = document.getElementById('address-label').value;
    const street = document.getElementById('address-street').value;
    const city = document.getElementById('address-city').value;
    const zip = document.getElementById('address-zip').value;
    const isDefault = document.getElementById('address-default').checked;

    try {
        await apiFetch('/users/addresses', {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${localStorage.getItem('userToken')}` },
            body: { label, street, city, zip, isDefault }
        });
        closeAddressModal();
        loadAddresses();
    } catch (err) {
        alert('Failed to add address: ' + err.message);
    }
};

async function setDefaultAddress(id) {
    try {
        await apiFetch(`/users/addresses/${id}/default`, {
            method: 'PUT',
            headers: { 'Authorization': `Bearer ${localStorage.getItem('userToken')}` }
        });
        loadAddresses();
    } catch (err) {
        alert('Failed to set default address');
    }
}

async function deleteAddress(id) {
    if (!confirm('Delete this address?')) return;
    try {
        await apiFetch(`/users/addresses/${id}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${localStorage.getItem('userToken')}` }
        });
        loadAddresses();
    } catch (err) {
        alert('Failed to delete address');
    }
}

// Referral Handlers
document.getElementById('copy-referral-btn').onclick = () => {
    const code = document.getElementById('referral-code-display').textContent;
    if (code === 'LOADING...') return;
    navigator.clipboard.writeText(code).then(() => {
        const btn = document.getElementById('copy-referral-btn');
        const originalText = btn.textContent;
        btn.textContent = 'Copied!';
        setTimeout(() => btn.textContent = originalText, 2000);
    });
};

document.getElementById('claim-referral-btn').onclick = async () => {
    const input = document.getElementById('claim-code-input');
    const code = input.value.trim();
    if (!code) return;

    try {
        const btn = document.getElementById('claim-referral-btn');
        btn.disabled = true;
        btn.textContent = 'Claiming...';
        const res = await apiFetch('/users/referral/claim', {
            method: 'POST',
            body: { code }
        });
        alert(res.message);
        loadProfile();
    } catch (err) {
        alert(err.message);
    } finally {
        const btn = document.getElementById('claim-referral-btn');
        btn.disabled = false;
        btn.textContent = 'Claim Code';
    }
};

async function loadRecentlyViewed() {
    const grid = document.getElementById('recently-viewed-grid');
    try {
        const items = await apiFetch('/users/recently-viewed');
        if (items.length === 0) {
            grid.innerHTML = '<p class="text-muted" style="grid-column: 1/-1;">You haven\'t viewed any products recently.</p>';
            return;
        }

        grid.innerHTML = items.map(item => `
            <div class="card" style="padding: 15px; display: flex; gap: 15px; align-items: center;">
                <img src="${item.imageURL || 'images/product_placeholder.svg'}" style="width: 80px; height: 80px; object-fit: contain;">
                <div style="flex: 1;">
                    <h4 style="margin: 0;">${item.name}</h4>
                    <div style="color: var(--primary); font-weight: 700;">${formatCurrency(item.basePrice)}</div>
                </div>
                <button class="btn btn-sm btn-primary" onclick="window.location.href='shop.html?search=${encodeURIComponent(item.name)}'">View</button>
            </div>
        `).join('');
    } catch (err) {
        grid.innerHTML = '<p class="text-error">Failed to load recently viewed items.</p>';
    }
}
