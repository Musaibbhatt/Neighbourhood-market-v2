document.addEventListener('DOMContentLoaded', async () => {
    const params = new URLSearchParams(window.location.search);
    const orderId = params.get('id');

    if (!orderId) {
        window.location.href = 'index.html';
        return;
    }

    document.getElementById('order-id-track').textContent = `Order #${orderId}`;
    await loadOrderStatus(orderId);
});

async function loadOrderStatus(id) {
    try {
        const order = await apiFetch(`/orders/${id}`);
        renderTimeline(order);
        setupCancellation(order);
        if (typeof setupReturnRequest === 'function') setupReturnRequest(order);
    } catch (e) {
        console.error(e);
        document.getElementById('timeline-container').innerHTML = '<p class="text-error">Order not found or error loading status.</p>';
    }
}

function renderTimeline(order) {
    const container = document.getElementById('timeline-container');
    const allStatuses = ['Order Received', 'Packed', 'Out for Delivery', 'Delivered'];

    // Find current index
    const currentIndex = allStatuses.indexOf(order.orderStatus);

    container.innerHTML = '';

    if (order.isCancelled) {
        document.getElementById('status-title').textContent = 'Order Cancelled';
        document.getElementById('status-title').style.color = 'var(--error)';
        document.getElementById('cancelled-message').classList.remove('d-none');
        return;
    }

    allStatuses.forEach((status, index) => {
        const item = document.createElement('div');
        item.className = `timeline-item ${index <= currentIndex ? 'active' : ''}`;

        const historyItem = order.statusHistory.find(h => h.status === status);
        const timeStr = historyItem ? new Date(historyItem.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '';

        item.innerHTML = `
            <div class="timeline-dot"></div>
            <div class="timeline-content">
                <h4>${status}</h4>
                <p>${historyItem ? `Confirmed at ${timeStr}` : 'Pending'}</p>
            </div>
        `;
        container.appendChild(item);
    });
}

function setupCancellation(order) {
    const cancelSection = document.getElementById('cancel-section');
    const cancelBtn = document.getElementById('btn-cancel-order');

    // Only allow cancellation if status is "Order Received" and not already cancelled
    if (order.orderStatus === 'Order Received' && !order.isCancelled) {
        cancelSection.classList.remove('d-none');
        cancelBtn.onclick = async () => {
            if (confirm('Are you sure you want to cancel this order?')) {
                try {
                    cancelBtn.disabled = true;
                    cancelBtn.textContent = 'Cancelling...';
                    await apiFetch(`/orders/${order._id}/cancel`, { method: 'PUT' });
                    location.reload();
                } catch (e) {
                    alert('Failed to cancel order.');
                    cancelBtn.disabled = false;
                    cancelBtn.textContent = 'Cancel Order';
                }
            }
        };
    } else {
        cancelSection.classList.add('d-none');
    }
}

function setupReturnRequest(order) {
    const returnSection = document.getElementById('return-section');
    const returnBtn = document.getElementById('btn-request-return');
    const statusMsg = document.getElementById('return-status-message');
    const modal = document.getElementById('return-modal');
    const form = document.getElementById('return-form');

    if (!returnSection) return;

    if (order.orderStatus === 'Delivered' && !order.isCancelled) {
        returnSection.classList.remove('d-none');

        if (order.returnRequest && order.returnRequest.status) {
            // Request already exists
            const actionsDiv = document.getElementById('return-request-actions');
            if (actionsDiv) actionsDiv.classList.add('d-none');

            statusMsg.classList.remove('d-none');

            let bgColor = '#fff8e1'; // Pending
            let textColor = '#f57c00';

            if (order.returnRequest.status === 'Approved') { bgColor = '#e8f5e9'; textColor = '#2e7d32'; }
            if (order.returnRequest.status === 'Rejected') { bgColor = '#ffebee'; textColor = '#c62828'; }
            if (order.returnRequest.status === 'Completed') { bgColor = '#e3f2fd'; textColor = '#1565c0'; }

            statusMsg.style.backgroundColor = bgColor;
            statusMsg.style.color = textColor;
            statusMsg.innerHTML = `
                <strong>${order.returnRequest.requestType} Status: ${order.returnRequest.status}</strong><br>
                <small>${order.returnRequest.adminNotes || 'We are reviewing your request.'}</small>
            `;
        } else {
            // Allow submission
            if (returnBtn) returnBtn.onclick = () => modal.classList.remove('d-none');

            if (form) {
                form.onsubmit = async (e) => {
                    e.preventDefault();
                    const payload = {
                        requestType: form.querySelector('input[name="requestType"]:checked').value,
                        reason: document.getElementById('return-reason').value
                    };

                    try {
                        returnBtn.disabled = true;
                        returnBtn.textContent = 'Submitting...';
                        await apiFetch(`/orders/${order._id}/return-request`, {
                            method: 'POST',
                            body: payload
                        });
                        location.reload();
                    } catch (err) {
                        alert('Failed to submit request: ' + err.message);
                        returnBtn.disabled = false;
                        returnBtn.textContent = 'Request Refund/Replacement';
                    }
                };
            }
        }
    }
}

window.closeReturnModal = function () {
    document.getElementById('return-modal').classList.add('d-none');
}
