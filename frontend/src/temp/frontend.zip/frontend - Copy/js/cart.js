document.addEventListener('DOMContentLoaded', () => {
    renderCart().catch(err => console.error(err));
    setupCartActions();
});

async function renderCart() {
    const cartContainer = document.getElementById('cart-items');
    const summarySubtotal = document.getElementById('summary-subtotal');
    const summaryTotal = document.getElementById('summary-total');
    const emptyState = document.getElementById('empty-cart-state');
    const cartContent = document.getElementById('cart-content');
    const progressContainer = document.getElementById('delivery-progress-container');

    if (!cartContainer || !summarySubtotal || !summaryTotal) return;

    const cart = getCart();

    if (cart.length === 0) {
        emptyState.classList.remove('d-none');
        cartContent.classList.add('d-none');
        return;
    }

    emptyState.classList.add('d-none');
    cartContent.classList.remove('d-none');

    cartContainer.innerHTML = '';
    let total = 0;

    cart.forEach((item, index) => {
        const itemTotal = item.price * item.quantity;
        total += itemTotal;

        const row = document.createElement('div');
        row.className = 'cart-item';
        row.style.display = 'grid';
        row.style.gridTemplateColumns = '80px 1fr auto auto auto';
        row.style.gap = '20px';
        row.style.alignItems = 'center';
        row.style.padding = '15px 0';
        row.style.borderBottom = '1px solid var(--border)';

        row.innerHTML = `
            <img src="${item.image || 'images/product_placeholder.svg'}" alt="${item.name}" style="width: 100%; border-radius: 8px;">
            <div>
                <h4 style="margin-bottom: 5px;">${item.name}</h4>
                <div class="text-muted" style="margin-bottom: 8px;">${formatCurrency(item.price)}</div>
                <button class="btn-save-later" data-index="${index}" style="font-size: 0.8rem; color: var(--primary); font-weight: 500; text-decoration: underline;">Save for later</button>
            </div>
            <div style="display: flex; align-items: center; gap: 10px; background: #f0f0f0; padding: 5px 10px; border-radius: 20px;">
                <button class="btn-qty-minus" data-index="${index}" style="font-weight: bold; width: 24px;">-</button>
                <span style="min-width: 20px; text-align: center;">${item.quantity}</span>
                <button class="btn-qty-plus" data-index="${index}" style="font-weight: bold; width: 24px;">+</button>
            </div>
            <div style="font-weight: bold; min-width: 80px; text-align: right;">
                ${formatCurrency(itemTotal)}
            </div>
            <button class="btn-remove-item text-error" data-index="${index}" style="font-size: 1.2rem;" title="Remove item">&times;</button>
        `;
        cartContainer.appendChild(row);
    });

    summarySubtotal.textContent = formatCurrency(total);

    // Fetch store config to drive delivery logic (threshold + fee)
    let freeDeliveryThreshold = 500;
    let defaultDeliveryFee = 50;
    try {
        const config = await apiFetch('/store-config');
        if (typeof config.freeDeliveryThreshold === 'number') freeDeliveryThreshold = config.freeDeliveryThreshold;
        if (typeof config.defaultDeliveryFee === 'number') defaultDeliveryFee = config.defaultDeliveryFee;
    } catch (e) {
        // fall back to defaults
    }

    // Delivery Progress Logic:
    // - Show only after items are added
    // - Show only if below free-delivery threshold
    const progressBar = document.getElementById('delivery-progress-bar');
    const progressText = document.getElementById('delivery-progress-text');
    const progressPercentText = document.getElementById('delivery-progress-percent');

    const shouldShowProgress = total > 0 && total < freeDeliveryThreshold;
    if (progressContainer) progressContainer.style.display = shouldShowProgress ? 'block' : 'none';

    if (shouldShowProgress && progressBar && progressText && progressPercentText) {
        const progressPercent = Math.min((total / freeDeliveryThreshold) * 100, 100);
        progressBar.style.width = `${progressPercent}%`;
        progressPercentText.textContent = `${Math.round(progressPercent)}%`;

        const remaining = freeDeliveryThreshold - total;
        progressText.textContent = `Add ${formatCurrency(remaining)} more for FREE delivery`;
        progressText.style.color = "inherit";
        progressBar.style.background = "var(--secondary)";
    }

    const deliveryFee = total >= freeDeliveryThreshold ? 0 : defaultDeliveryFee;
    const totalWithDelivery = total + deliveryFee;

    document.getElementById('summary-total').textContent = formatCurrency(totalWithDelivery);

    // Store values
    localStorage.setItem('cartTotal', total.toString());
    localStorage.setItem('deliveryFee', deliveryFee.toString());

    renderSavedItems();
}

/**
 * Save for Later Logic
 */
function renderSavedItems() {
    const savedContainer = document.getElementById('saved-items-grid');
    const savedSection = document.getElementById('save-for-later-section');
    if (!savedContainer) return;

    const savedItems = JSON.parse(localStorage.getItem('saveForLater') || '[]');

    if (savedItems.length === 0) {
        savedSection.classList.add('d-none');
        return;
    }

    savedSection.classList.remove('d-none');
    savedContainer.innerHTML = '';

    savedItems.forEach((item, index) => {
        const card = document.createElement('div');
        card.className = 'card';
        card.style.padding = '15px';
        card.innerHTML = `
            <img src="${item.image || 'images/product_placeholder.svg'}" style="width: 100%; height: 120px; object-fit: contain; margin-bottom: 10px;">
            <h4 style="font-size: 0.95rem; margin-bottom: 5px;">${item.name}</h4>
            <div style="font-weight: 700; color: var(--primary); margin-bottom: 15px;">${formatCurrency(item.price)}</div>
            <div style="display: flex; flex-direction: column; gap: 8px;">
                <button class="btn btn-primary btn-sm btn-move-cart" data-index="${index}">Move to Cart</button>
                <button class="btn-outline btn-sm btn-remove-saved" data-index="${index}" style="font-size: 0.8rem;">Remove</button>
            </div>
        `;
        savedContainer.appendChild(card);
    });

    attachSavedItemListeners();
}

function attachSavedItemListeners() {
    document.querySelectorAll('.btn-move-cart').forEach(btn => {
        btn.addEventListener('click', () => {
            const index = parseInt(btn.dataset.index);
            const savedItems = JSON.parse(localStorage.getItem('saveForLater') || '[]');
            const item = savedItems.splice(index, 1)[0];

            const cart = getCart();
            const existing = cart.find(c => c.id === item.id);
            if (existing) existing.quantity += 1;
            else cart.push({ ...item, quantity: 1 });

            localStorage.setItem('saveForLater', JSON.stringify(savedItems));
            saveCart(cart);
            renderCart();
            updateCartIcon();
        });
    });

    document.querySelectorAll('.btn-remove-saved').forEach(btn => {
        btn.addEventListener('click', () => {
            const index = parseInt(btn.dataset.index);
            const savedItems = JSON.parse(localStorage.getItem('saveForLater') || '[]');
            savedItems.splice(index, 1);
            localStorage.setItem('saveForLater', JSON.stringify(savedItems));
            renderSavedItems();
        });
    });
}

function setupCartActions() {
    const cartContainer = document.getElementById('cart-items');
    if (!cartContainer) return;

    cartContainer.addEventListener('click', (e) => {
        const cart = getCart();

        if (e.target.classList.contains('btn-qty-plus')) {
            const index = e.target.dataset.index;
            cart[index].quantity += 1;
            saveCart(cart);
            renderCart();
        }
        else if (e.target.classList.contains('btn-qty-minus')) {
            const index = e.target.dataset.index;
            if (cart[index].quantity > 1) {
                cart[index].quantity -= 1;
                saveCart(cart);
                renderCart();
            }
        }
        else if (e.target.classList.contains('btn-save-later')) {
            const index = parseInt(e.target.dataset.index);
            const item = cart.splice(index, 1)[0];

            const savedItems = JSON.parse(localStorage.getItem('saveForLater') || '[]');
            savedItems.push(item);

            localStorage.setItem('saveForLater', JSON.stringify(savedItems));
            saveCart(cart);
            renderCart();
            updateCartIcon();
        }
        else if (e.target.classList.contains('btn-remove-item')) {
            const index = e.target.dataset.index;
            cart.splice(index, 1);
            saveCart(cart);
            renderCart();
        }
    });

    const clearBtn = document.getElementById('clear-cart-btn');
    if (clearBtn) {
        clearBtn.addEventListener('click', () => {
            if (confirm('Are you sure you want to clear your cart?')) {
                clearCart();
                renderCart();
            }
        });
    }
}
