// Service Worker for Neighbourhood Market
// Cache-first strategy for static assets

const CACHE_NAME = 'neighbourhood-market-v2';
const ASSETS_TO_CACHE = [
    '/',
    '/index.html',
    '/shop.html',
    '/cart.html',
    '/profile.html',
    '/about.html',
    '/contact.html',
    '/offers.html',
    '/css/style.css',
    '/js/main.js',
    '/js/shop.js',
    '/images/hero_banner.svg',
    '/images/product_placeholder.svg',
    '/images/category_produce.svg',
    '/images/category_dairy.svg',
    '/images/category_bakery.svg',
    '/images/recipe_placeholder.svg'
];

// Install — cache static assets
self.addEventListener('install', (event) => {
    event.waitUntil(
        caches.open(CACHE_NAME).then((cache) => {
            return cache.addAll(ASSETS_TO_CACHE);
        })
    );
    self.skipWaiting();
});

// Activate — clean up old caches
self.addEventListener('activate', (event) => {
    event.waitUntil(
        caches.keys().then((keys) =>
            Promise.all(
                keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key))
            )
        )
    );
    self.clients.claim();
});

// Fetch — cache-first for static, network-first for API
self.addEventListener('fetch', (event) => {
    const url = new URL(event.request.url);

    // Let API requests go straight to network
    if (url.pathname.startsWith('/api/')) {
        event.respondWith(
            fetch(event.request).catch(() =>
                new Response(JSON.stringify({ message: 'Offline — please check your connection.' }), {
                    status: 503,
                    headers: { 'Content-Type': 'application/json' }
                })
            )
        );
        return;
    }

    // Cache-first for everything else
    event.respondWith(
        caches.match(event.request).then((cached) => {
            return (
                cached ||
                fetch(event.request).then((response) => {
                    // Cache valid GET responses
                    if (response.ok && event.request.method === 'GET') {
                        const clone = response.clone();
                        caches.open(CACHE_NAME).then((cache) => cache.put(event.request, clone));
                    }
                    return response;
                })
            );
        })
    );
});
